package middlewares

import (
	"aghris/config"
	"net/http"
	"strings"

	"github.com/golang-jwt/jwt/v4"
	"github.com/gin-gonic/gin"
)

// **🔹 بيانات المستخدم داخل التوكن**
type Claims struct {
	UserID          uint   `json:"user_id"`
	Role            string `json:"role"`
	CanCreateAdmins bool   `json:"can_create_admins"`
	jwt.RegisteredClaims // ✅ استبدال `StandardClaims` بـ `RegisteredClaims`
}

// **✅ التحقق من صلاحية التوكن**
func AuthMiddleware() gin.HandlerFunc {
	return func(c *gin.Context) {
		tokenString := c.GetHeader("Authorization")
		if tokenString == "" {
			c.JSON(http.StatusUnauthorized, gin.H{"error": "Authorization header required"})
			c.Abort()
			return
		}

		// إزالة "Bearer " من التوكن
		tokenString = strings.TrimPrefix(tokenString, "Bearer ")

		claims := &Claims{}
		token, err := jwt.ParseWithClaims(tokenString, claims, func(token *jwt.Token) (interface{}, error) {
			return []byte(config.JWT_SECRET), nil // ✅ استخدام `config.JWT_SECRET`
		})

		if err != nil || !token.Valid {
			c.JSON(http.StatusUnauthorized, gin.H{"error": "Invalid token"})
			c.Abort()
			return
		}

		// ✅ التحقق من استخراج `user_id` بشكل صحيح
		if claims.UserID == 0 {
			c.JSON(http.StatusUnauthorized, gin.H{"error": "Invalid user ID in token"})
			c.Abort()
			return
		}

		// حفظ بيانات المستخدم المستخرجة من التوكن داخل `context`
		c.Set("user_id", claims.UserID)
		c.Set("role", claims.Role)
		c.Set("can_create_admins", claims.CanCreateAdmins)

		c.Next()
	}
}

// **✅ التحقق من صلاحية إنشاء الإداريين**
func AdminOnlyMiddleware() gin.HandlerFunc {
	return func(c *gin.Context) {
		// استرجاع القيم المخزنة من `AuthMiddleware`
		canCreateAdmins, exists := c.Get("can_create_admins")
		if !exists {
			c.JSON(http.StatusForbidden, gin.H{"error": "Unauthorized - You cannot create admins"})
			c.Abort()
			return
		}

		// ✅ التأكد من أن `canCreateAdmins` هو `bool`
		canCreate, ok := canCreateAdmins.(bool)
		if !ok || !canCreate {
			c.JSON(http.StatusForbidden, gin.H{"error": "Unauthorized - You cannot create admins"})
			c.Abort()
			return
		}

		c.Next()
	}
}
