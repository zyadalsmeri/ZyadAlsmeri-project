package main

import (
	"aghris/config"
	"aghris/routes"
	"log"

	"github.com/gin-gonic/gin"
)

func main() {
	// الاتصال بقاعدة البيانات
	config.ConnectDB()

	// تحقق أن الاتصال ناجح
	if config.DB == nil {
		log.Fatal("❌ Database connection failed.")
	}

	// تهيئة وتشغيل السيرفر
	router := gin.Default()

	// إضافة مسارات المصادقة (للدخول الإداري فقط حاليًا)
	routes.AuthRoutes(router)

	// إضافة مسارات المنتجات
	routes.ProductRoutes(router)

	// إضافة مسارات سلة التسوق
	routes.CartRoutes(router)

	// إضافة مسارات الإداريين
	api := router.Group("/api")
    routes.AdminRoutes(api)

	// إضافة مسارات العملاء (Customers)
	routes.CustomerRoutes(router)

	// إضافة مسارات الموردين
	routes.SupplierRoutes(router)

	// هذا للعملاء أو أي زائر
	routes.PublicProductRoutes(router)
	
	api = router.Group("/api")
	routes.OrderRoutes(api)
	
	// تشغيل السيرفر على المنفذ 8080
	router.Run(":8080")
}
