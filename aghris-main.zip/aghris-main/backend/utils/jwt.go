package utils

import (
	"aghris/config"
	"time"

	"github.com/golang-jwt/jwt/v4"
)

// بيانات التوكن العامة لجميع المستخدمين
type Claims struct {
	UserID          uint   `json:"user_id"`           // ✅ تغيير `CustomerID` إلى `UserID` ليشمل الجميع
	Role            string `json:"role"`              // ✅ إضافة `Role` لتحديد نوع المستخدم (admin, customer, supplier)
	CanCreateAdmins bool   `json:"can_create_admins"` // 🔥 أضف هذا
	jwt.RegisteredClaims
}

// **🔹 إنشاء JWT لأي مستخدم بناءً على دوره**
func GenerateJWT(userID uint, role string, canCreateAdmins bool) (string, error) {
	claims := Claims{
		UserID:          userID,
		Role:            role,
		CanCreateAdmins: canCreateAdmins, // 🔥 هنا
		RegisteredClaims: jwt.RegisteredClaims{
			ExpiresAt: jwt.NewNumericDate(time.Now().Add(time.Hour * 24)), // صلاحية 24 ساعة
		},
	}

	token := jwt.NewWithClaims(jwt.SigningMethodHS256, claims)
	return token.SignedString([]byte(config.JWT_SECRET)) // ✅ استخدام المفتاح السري المخزن في `config`
}
