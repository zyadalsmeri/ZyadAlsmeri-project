package routes

import (
	"aghris/config"
	"aghris/middlewares"
	"aghris/models"
	"net/http"
	"strconv"

	"github.com/gin-gonic/gin"
)

// ✅ تعريف مسارات إدارة المنتجات (Admins Only)
func ProductRoutes(router *gin.Engine) {
	productRoutes := router.Group("/admin/products").Use(middlewares.AuthMiddleware())
	{
		productRoutes.POST("/", CreateProduct)
		productRoutes.PUT("/:id", UpdateProduct)
		productRoutes.DELETE("/:id", DeleteProduct)
		productRoutes.GET("/", GetProducts)
		productRoutes.GET("/:id", GetProductDetails)
	}
}

// ✅ تعريف مسارات عامة للوصول إلى المنتجات
func PublicProductRoutes(router *gin.Engine) {
	publicRoutes := router.Group("/products")
	{
		publicRoutes.GET("/", GetProducts)
		publicRoutes.GET("/:id", GetProductDetails)
	}
}

// ✅ نموذج الإدخال للتحقق من صحة البيانات
type ProductInput struct {
	Name       string  `json:"name" validate:"required"`
	Price      float64 `json:"price" validate:"required,gt=0"`
	Picture    string  `json:"picture,omitempty"`
	CategoryID int     `json:"category_id" validate:"required"`
	AdminID    int     `json:"admin_id" validate:"required"`
}

// ✅ إنشاء منتج جديد
func CreateProduct(c *gin.Context) {
	var input ProductInput

	if err := c.ShouldBindJSON(&input); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": "Invalid JSON format", "details": err.Error()})
		return
	}

	if err := middlewares.Validate.Struct(input); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": err.Error()})
		return
	}

	product := models.Product{
		Name:       input.Name,
		Price:      input.Price,
		Picture:    input.Picture,
		CategoryID: input.CategoryID,
		AdminID:    input.AdminID,
	}

	if err := config.DB.Create(&product).Error; err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "Could not create product", "details": err.Error()})
		return
	}

	c.JSON(http.StatusOK, gin.H{"message": "Product created successfully", "product": product})
}

// ✅ تعديل منتج
func UpdateProduct(c *gin.Context) {
	id := c.Param("id")
	productID, err := strconv.ParseUint(id, 10, 32)
	if err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": "Invalid product ID format"})
		return
	}

	var product models.Product
	if err := config.DB.First(&product, "product_id = ?", productID).Error; err != nil {
		c.JSON(http.StatusNotFound, gin.H{"error": "Product not found"})
		return
	}

	var input ProductInput
	if err := c.ShouldBindJSON(&input); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": "Invalid input", "details": err.Error()})
		return
	}

	if err := middlewares.Validate.Struct(input); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": err.Error()})
		return
	}

	product.Name = input.Name
	product.Price = input.Price
	product.Picture = input.Picture
	product.CategoryID = input.CategoryID
	product.AdminID = input.AdminID

	if err := config.DB.Save(&product).Error; err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "Could not update product", "details": err.Error()})
		return
	}

	c.JSON(http.StatusOK, gin.H{"message": "Product updated successfully", "product": product})
}

// ✅ حذف منتج
func DeleteProduct(c *gin.Context) {
	id := c.Param("id")
	productID, err := strconv.ParseUint(id, 10, 32)
	if err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": "Invalid product ID format"})
		return
	}

	if err := config.DB.Delete(&models.Product{}, "product_id = ?", productID).Error; err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "Could not delete product", "details": err.Error()})
		return
	}

	c.JSON(http.StatusOK, gin.H{"message": "Product deleted successfully"})
}

// ✅ جلب المنتجات مع الكمية من المخزون
func GetProducts(c *gin.Context) {
	var products []models.Product
	if err := config.DB.Find(&products).Error; err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "Could not fetch products", "details": err.Error()})
		return
	}

	var results []map[string]interface{}
	for _, product := range products {
		var totalQuantity int64
		config.DB.Model(&models.Inventory{}).Where("product_id = ?", product.ProductID).Select("SUM(inventory_quantity)").Scan(&totalQuantity)

		results = append(results, gin.H{
			"product":        product,
			"total_quantity": totalQuantity,
		})
	}

	c.JSON(http.StatusOK, gin.H{"products": results})
}

// ✅ تفاصيل منتج مع الكمية
func GetProductDetails(c *gin.Context) {
	id := c.Param("id")
	productID, err := strconv.ParseUint(id, 10, 32)
	if err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": "Invalid product ID format"})
		return
	}

	var product models.Product
	if err := config.DB.First(&product, "product_id = ?", productID).Error; err != nil {
		c.JSON(http.StatusNotFound, gin.H{"error": "Product not found"})
		return
	}

	var totalQuantity int64
	config.DB.Model(&models.Inventory{}).Where("product_id = ?", product.ProductID).Select("SUM(inventory_quantity)").Scan(&totalQuantity)

	c.JSON(http.StatusOK, gin.H{
		"product":        product,
		"total_quantity": totalQuantity,
	})
}
