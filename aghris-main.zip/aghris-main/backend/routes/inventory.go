package routes

import (
	"aghris/config"
	"aghris/middlewares"
	"aghris/models"
	"net/http"

	"github.com/gin-gonic/gin"
)

// 🔹 تعريف مسارات إدارة المخزون
func InventoryRoutes(router *gin.Engine) {
	inventoryRoutes := router.Group("/inventory").Use(middlewares.AuthMiddleware())
	{
		// ✅ حذف POST – ما عاد نسمح بإضافة من المستخدمين مباشرة
		// inventoryRoutes.POST("/", CreateInventory)

		inventoryRoutes.GET("/", GetInventory)
		inventoryRoutes.GET("/:id", GetInventoryItem)
		inventoryRoutes.PUT("/:id", UpdateInventory)
		inventoryRoutes.DELETE("/:id", DeleteInventory)
	}
}

// 🔹 جلب جميع عناصر المخزون
func GetInventory(c *gin.Context) {
	var inventory []models.Inventory
	if err := config.DB.Preload("Product").Preload("Supplier").Find(&inventory).Error; err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "Could not fetch inventory"})
		return
	}
	c.JSON(http.StatusOK, inventory)
}

// 🔹 جلب عنصر واحد من المخزون
func GetInventoryItem(c *gin.Context) {
	id := c.Param("id")
	var inventory models.Inventory
	if err := config.DB.Preload("Product").Preload("Supplier").First(&inventory, "inventory_id = ?", id).Error; err != nil {
		c.JSON(http.StatusNotFound, gin.H{"error": "Inventory item not found"})
		return
	}
	c.JSON(http.StatusOK, inventory)
}

// 🔹 تحديث عنصر في المخزون
func UpdateInventory(c *gin.Context) {
	id := c.Param("id")
	var inventory models.Inventory

	if err := config.DB.First(&inventory, "inventory_id = ?", id).Error; err != nil {
		c.JSON(http.StatusNotFound, gin.H{"error": "Inventory item not found"})
		return
	}

	if err := c.ShouldBindJSON(&inventory); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": "Invalid input format"})
		return
	}

	if err := middlewares.Validate.Struct(inventory); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": err.Error()})
		return
	}

	if err := config.DB.Save(&inventory).Error; err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "Could not update inventory item"})
		return
	}

	c.JSON(http.StatusOK, inventory)
}

// 🔹 حذف عنصر من المخزون
func DeleteInventory(c *gin.Context) {
	id := c.Param("id")
	if err := config.DB.Delete(&models.Inventory{}, "inventory_id = ?", id).Error; err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "Could not delete inventory item"})
		return
	}
	c.JSON(http.StatusOK, gin.H{"message": "Inventory item deleted successfully"})
}

// 🔹 تحديث كمية المخزون بعد إنشاء الطلب (غير مستخدمة الآن لأننا نستخدم FIFO من orders.go)
func UpdateInventoryAfterOrder(c *gin.Context, orderID uint) {
	// ⚠️ قد لا نحتاجها الآن، لأن الخصم صار في FIFO داخل CreateOrder
	// ممكن لاحقًا تستخدمها عند الإلغاء لإعادة الكمية بشكل أدق
	var orderItems []models.OrderItem
	if err := config.DB.Where("order_id = ?", orderID).Find(&orderItems).Error; err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "Failed to fetch order items"})
		return
	}

	for _, item := range orderItems {
		var inventory models.Inventory
		if err := config.DB.Where("product_id = ?", item.ProductID).First(&inventory).Error; err != nil {
			c.JSON(http.StatusBadRequest, gin.H{"error": "Product not found in inventory"})
			return
		}

		inventory.InventoryQuantity -= item.ProductQuantity
		config.DB.Save(&inventory)
	}
}
