package routes

import (
	"aghris/config"
	"aghris/middlewares"
	"aghris/models"
	"net/http"

	"github.com/gin-gonic/gin"
)

// ✅ مسارات التذاكر
func TicketRoutes(router *gin.Engine) {
	ticketRoutes := router.Group("/tickets").Use(middlewares.AuthMiddleware())
	{
		ticketRoutes.POST("/", CreateTicket)
		ticketRoutes.GET("/", GetTickets)
		ticketRoutes.GET("/:id", GetTicket)
		ticketRoutes.PUT("/:id", UpdateTicket)
		ticketRoutes.DELETE("/:id", DeleteTicket)
		ticketRoutes.POST("/:id/approve", ApproveTicket)
	}
}

// ✅ إنشاء تذكرة
func CreateTicket(c *gin.Context) {
	var input models.Ticket
	if err := c.ShouldBindJSON(&input); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": "Invalid input"})
		return
	}

	// ✅ التحقق من الطلب
	var request models.SupplyRequest
	if err := config.DB.First(&request, input.SupplyRequestID).Error; err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": "Supply request not found"})
		return
	}

	// ✅ التأكد أن المنتج في التكت مطابق للطلب
	if input.ProductID != request.ProductID {
		c.JSON(http.StatusBadRequest, gin.H{"error": "Product ID mismatch with supply request"})
		return
	}

	// ✅ منع التكرار (اختياري)
	var existing models.Ticket
	if err := config.DB.Where("supply_request_id = ?", input.SupplyRequestID).First(&existing).Error; err == nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": "Ticket already submitted for this supply request"})
		return
	}

	// ✅ تعيين السعر من الطلب
	input.TicketPrice = request.Price

	if err := middlewares.Validate.Struct(input); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": err.Error()})
		return
	}

	if err := config.DB.Create(&input).Error; err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "Could not create ticket"})
		return
	}

	c.JSON(http.StatusOK, input)
}

// ✅ الموافقة على التذكرة
func ApproveTicket(c *gin.Context) {
	id := c.Param("id")
	var ticket models.Ticket
	if err := config.DB.First(&ticket, id).Error; err != nil {
		c.JSON(http.StatusNotFound, gin.H{"error": "Ticket not found"})
		return
	}

	ticket.Status = "Accepted"
	if err := config.DB.Save(&ticket).Error; err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "Could not update ticket status"})
		return
	}

	inventory := models.Inventory{
		ProductID:         ticket.ProductID,
		SupplierID:        ticket.SupplierID,
		InventoryQuantity: ticket.TicketQuantity,
		InventoryPrice:    ticket.TicketPrice,
	}

	if err := config.DB.Create(&inventory).Error; err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "Could not add to inventory"})
		return
	}

	c.JSON(http.StatusOK, gin.H{
		"message":   "Ticket approved and added to inventory",
		"inventory": inventory,
	})
}

// ✅ جميع التذاكر
func GetTickets(c *gin.Context) {
	var tickets []models.Ticket
	if err := config.DB.Find(&tickets).Error; err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "Could not fetch tickets"})
		return
	}
	c.JSON(http.StatusOK, tickets)
}

// ✅ تذكرة مفردة
func GetTicket(c *gin.Context) {
	id := c.Param("id")
	var ticket models.Ticket
	if err := config.DB.First(&ticket, id).Error; err != nil {
		c.JSON(http.StatusNotFound, gin.H{"error": "Ticket not found"})
		return
	}
	c.JSON(http.StatusOK, ticket)
}

// ✅ تعديل تذكرة
func UpdateTicket(c *gin.Context) {
	id := c.Param("id")
	var ticket models.Ticket
	if err := config.DB.First(&ticket, id).Error; err != nil {
		c.JSON(http.StatusNotFound, gin.H{"error": "Ticket not found"})
		return
	}

	var input struct {
		TicketQuantity int    `json:"ticket_quantity"`
		Status         string `json:"status"`
	}

	if err := c.ShouldBindJSON(&input); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": "Invalid input"})
		return
	}

	ticket.TicketQuantity = input.TicketQuantity
	ticket.Status = input.Status

	if err := config.DB.Save(&ticket).Error; err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "Could not update ticket"})
		return
	}

	c.JSON(http.StatusOK, ticket)
}

// ✅ حذف تذكرة
func DeleteTicket(c *gin.Context) {
	id := c.Param("id")
	if err := config.DB.Delete(&models.Ticket{}, id).Error; err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "Could not delete ticket"})
		return
	}
	c.JSON(http.StatusOK, gin.H{"message": "Ticket deleted successfully"})
}
