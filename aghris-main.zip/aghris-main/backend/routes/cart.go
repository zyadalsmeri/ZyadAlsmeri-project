package routes

import (
	"aghris/config"
	"aghris/middlewares"
	"aghris/models"
	"net/http"

	"github.com/gin-gonic/gin"
)

// تعريف نموذج الإدخال للتحقق من صحة البيانات
type CartItemInput struct {
	CustomerID uint `json:"customer_id" validate:"required"`
	ProductID  uint `json:"product_id" validate:"required"`
	Quantity   int  `json:"quantity" validate:"required,gte=1"`
}

// تعريف مسارات إدارة سلة التسوق
func CartRoutes(router *gin.Engine) {
	cartRoutes := router.Group("/cart").Use(middlewares.AuthMiddleware())
	{
		cartRoutes.POST("/", AddToCart)
		cartRoutes.GET("/", GetCart)
		cartRoutes.DELETE("/:id", RemoveFromCart)
	}
}

// إضافة منتج إلى السلة مع التحقق من البيانات
func AddToCart(c *gin.Context) {
	var input CartItemInput

	if err := c.ShouldBindJSON(&input); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": "Invalid input format"})
		return
	}

	if err := middlewares.Validate.Struct(input); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": err.Error()})
		return
	}

	// إنشاء العنصر وإضافته إلى السلة
	cartItem := models.CartItem{
		CustomerID: input.CustomerID,
		ProductID:  input.ProductID,
		Quantity:   input.Quantity,
	}

	if err := config.DB.Create(&cartItem).Error; err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "Could not add item to cart"})
		return
	}

	c.JSON(http.StatusOK, cartItem)
}

// عرض المنتجات داخل السلة
func GetCart(c *gin.Context) {
	var cartItems []models.CartItem
	if err := config.DB.Find(&cartItems).Error; err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "Could not fetch cart items"})
		return
	}
	c.JSON(http.StatusOK, cartItems)
}

// حذف منتج من السلة
func RemoveFromCart(c *gin.Context) {
	id := c.Param("id")

	if err := config.DB.Delete(&models.CartItem{}, id).Error; err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "Could not remove item from cart"})
		return
	}

	c.JSON(http.StatusOK, gin.H{"message": "Item removed from cart successfully"})
}
