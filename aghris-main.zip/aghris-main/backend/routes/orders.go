package routes

import (
	"aghris/config"
	"aghris/middlewares"
	"aghris/models"
	"fmt"
	"math/rand"
	"net/http"
	"time"

	"github.com/gin-gonic/gin"
)

func OrderRoutes(router *gin.RouterGroup) {
	orderRoutes := router.Group("/orders").Use(middlewares.AuthMiddleware())
	{
		orderRoutes.POST("/create", CreateOrder)
		orderRoutes.GET("/", GetOrders)
		orderRoutes.GET("/:id", GetOrderDetails)
		orderRoutes.PUT("/:id", UpdateOrder)
		orderRoutes.DELETE("/:id", CancelOrder)
	}
}

func CreateOrder(c *gin.Context) {
	var order models.Order

	if err := c.ShouldBindJSON(&order); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": "Invalid input: check all fields"})
		return
	}

	if order.CustomerID == 0 || order.TotalPrice <= 0 {
		c.JSON(http.StatusBadRequest, gin.H{"error": "Customer ID and Total Price must be valid"})
		return
	}

	if order.OrderDate == "" {
		order.OrderDate = time.Now().Format("2006-01-02 15:04:05")
	}

	if order.TrackingOrder == "" {
		order.TrackingOrder = fmt.Sprintf("AGH-%06d", rand.Intn(1000000))
	}

	// ✅ التحقق من توفر الكمية لكل منتج
	for _, item := range order.OrderItems {
		var totalQty int64
		config.DB.
			Model(&models.Inventory{}).
			Where("product_id = ?", item.ProductID).
			Select("SUM(inventory_quantity)").
			Scan(&totalQty)

		if int64(item.ProductQuantity) > totalQty {
			c.JSON(http.StatusBadRequest, gin.H{
				"error": fmt.Sprintf("Insufficient inventory for product ID %d", item.ProductID),
			})
			return
		}
	}

	// ✅ إنشاء الطلب
	if err := config.DB.Create(&order).Error; err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "Could not create order"})
		return
	}

	// ✅ خصم الكميات من المخزون باستخدام FIFO
	for _, item := range order.OrderItems {
		remaining := item.ProductQuantity
		var inventoryBatches []models.Inventory

		config.DB.
			Where("product_id = ? AND inventory_quantity > 0", item.ProductID).
			Order("inventory_id ASC").
			Find(&inventoryBatches)

		for _, batch := range inventoryBatches {
			if remaining <= 0 {
				break
			}
			if batch.InventoryQuantity >= remaining {
				batch.InventoryQuantity -= remaining
				remaining = 0
			} else {
				remaining -= batch.InventoryQuantity
				batch.InventoryQuantity = 0
			}
			config.DB.Save(&batch)
		}
	}

	c.JSON(http.StatusOK, order)
}

func GetOrders(c *gin.Context) {
	var orders []models.Order
	if err := config.DB.Find(&orders).Error; err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "Could not fetch orders"})
		return
	}
	c.JSON(http.StatusOK, orders)
}

func GetOrderDetails(c *gin.Context) {
	id := c.Param("id")
	var order models.Order

	if err := config.DB.First(&order, "order_id = ?", id).Error; err != nil {
		c.JSON(http.StatusNotFound, gin.H{"error": "Order not found"})
		return
	}

	c.JSON(http.StatusOK, order)
}

func UpdateOrder(c *gin.Context) {
	id := c.Param("id")
	var order models.Order

	if err := config.DB.First(&order, "order_id = ?", id).Error; err != nil {
		c.JSON(http.StatusNotFound, gin.H{"error": "Order not found"})
		return
	}

	if err := c.ShouldBindJSON(&order); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": "Invalid input"})
		return
	}

	if err := config.DB.Save(&order).Error; err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "Could not update order"})
		return
	}

	c.JSON(http.StatusOK, order)
}

func RestoreInventoryAfterCancel(c *gin.Context, orderID uint) {
	var orderItems []models.OrderItem
	if err := config.DB.Where("order_id = ?", orderID).Find(&orderItems).Error; err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "Failed to fetch order items"})
		return
	}

	for _, item := range orderItems {
		var inventory models.Inventory
		if err := config.DB.Where("product_id = ?", item.ProductID).First(&inventory).Error; err != nil {
			continue
		}

		// إعادة الكمية إلى المخزون (لأول سجل فقط — يمكن تطويره لاحقًا ليراعي نفس خصم FIFO بالعكس)
		inventory.InventoryQuantity += item.ProductQuantity
		config.DB.Save(&inventory)
	}
}

func CancelOrder(c *gin.Context) {
	id := c.Param("id")

	var order models.Order
	if err := config.DB.First(&order, id).Error; err != nil {
		c.JSON(http.StatusNotFound, gin.H{"error": "Order not found"})
		return
	}

	RestoreInventoryAfterCancel(c, order.OrderID)

	if err := config.DB.Delete(&order).Error; err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "Could not cancel order"})
		return
	}

	c.JSON(http.StatusOK, gin.H{"message": "Order cancelled and inventory restored"})
}
