package routes

import (
	"aghris/config"
	"aghris/middlewares"
	"aghris/models"
	"aghris/utils" // ✅ إضافة utils لإنشاء التوكن
	"net/http"
	"strconv"

	"github.com/gin-gonic/gin"
)

// **🔹 تعريف مسارات إدارة العملاء**
func CustomerRoutes(router *gin.Engine) {
	customerRoutes := router.Group("/customers")
	{
		// ✅ السماح بالتسجيل بدون توكن
		customerRoutes.POST("/register", RegisterCustomer)
	}

	// ✅ هذه المسارات تتطلب مصادقة بعد تسجيل الدخول
	authenticatedRoutes := router.Group("/customers").Use(middlewares.AuthMiddleware())
	{
		authenticatedRoutes.GET("/:id", GetCustomer)
		authenticatedRoutes.PUT("/:id", UpdateCustomer)
		authenticatedRoutes.DELETE("/:id", DeleteCustomer)
	}
}

// **🔹 نموذج التحقق من البيانات عند التسجيل**
type CustomerInput struct {
	Name           string `json:"name" validate:"required,min=3"`
	Username       string `json:"username" validate:"required,alphanum"`
	Email          string `json:"email" validate:"required,email"`
	Password       string `json:"password" validate:"required,min=6"`
	City           string `json:"city" validate:"required"`
	Street         string `json:"street" validate:"required"`
	CustomerMobile string `json:"customer_mobile" validate:"required"`
}

// **✅ تسجيل مستخدم جديد**
func RegisterCustomer(c *gin.Context) {
	var input CustomerInput

	// التحقق من صحة البيانات المستلمة
	if err := c.ShouldBindJSON(&input); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": "Invalid JSON format"})
		return
	}

	// التحقق من صحة الإدخال باستخدام Validator المشترك
	if err := middlewares.Validate.Struct(input); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": err.Error()})
		return
	}

	// **✅ إنشاء مستخدم جديد**
	customer := models.Customer{
		Name:           input.Name,
		Username:       input.Username,
		Email:          input.Email,
		Password:       input.Password,
		City:           input.City,
		Street:         input.Street,
		CustomerMobile: input.CustomerMobile,
	}

	if err := config.DB.Create(&customer).Error; err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "Could not register customer"})
		return
	}

	// ✅ **إنشاء توكن JWT للمستخدم الجديد**
	token, err := utils.GenerateJWT(customer.CustomerID,"customer", false) // 🔹 إنشاء توكن للمستخدم
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "Failed to generate token"})
		return
	}

	// ✅ **إرجاع بيانات المستخدم مع التوكن**
	c.JSON(http.StatusOK, gin.H{
		"customer": customer,
		"token":    token, // 🔹 إرسال التوكن إلى الفرونت
	})
}

// **✅ جلب بيانات عميل محدد**
func GetCustomer(c *gin.Context) {
	var customer models.Customer
	idParam := c.Param("id") // ID المطلوب من الرابط

	// ✅ تحويل idParam إلى `uint`
	id, err := strconv.ParseUint(idParam, 10, 32)
	if err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": "Invalid customer ID"})
		return
	}

	// 🛑 الحصول على ID المستخدم من التوكن
	userID, exists := c.Get("user_id")
	if !exists {
		c.JSON(http.StatusUnauthorized, gin.H{"error": "Unauthorized"})
		return
	}

	// ✅ تحويل `userID` إلى `uint`
	userIDUint, ok := userID.(uint)
	if !ok {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "Invalid token data"})
		return
	}

	// 🛑 التحقق مما إذا كان المستخدم يطلب بياناته فقط
	if userIDUint != uint(id) {
		c.JSON(http.StatusForbidden, gin.H{"error": "Access denied"})
		return
	}

	// ✅ استرجاع بيانات العميل إذا كان يطلب بياناته فقط
	if err := config.DB.First(&customer, id).Error; err != nil {
		c.JSON(http.StatusNotFound, gin.H{"error": "Customer not found"})
		return
	}

	c.JSON(http.StatusOK, customer)
}

// **✅ تعديل بيانات مستخدم**
func UpdateCustomer(c *gin.Context) {
	var customer models.Customer
	id := c.Param("id")

	if err := config.DB.First(&customer, id).Error; err != nil {
		c.JSON(http.StatusNotFound, gin.H{"error": "Customer not found"})
		return
	}

	var input CustomerInput
	if err := c.ShouldBindJSON(&input); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": "Invalid JSON format"})
		return
	}

	// التحقق من صحة الإدخال باستخدام Validator المشترك
	if err := middlewares.Validate.Struct(input); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": err.Error()})
		return
	}

	// ✅ تحديث بيانات العميل
	customer.Name = input.Name
	customer.Username = input.Username
	customer.Email = input.Email
	customer.Password = input.Password
	customer.City = input.City
	customer.Street = input.Street

	if err := config.DB.Save(&customer).Error; err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "Could not update customer"})
		return
	}

	c.JSON(http.StatusOK, customer)
}

// **✅ حذف مستخدم**
func DeleteCustomer(c *gin.Context) {
	id := c.Param("id")

	if err := config.DB.Delete(&models.Customer{}, id).Error; err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "Could not delete customer"})
		return
	}
	c.JSON(http.StatusOK, gin.H{"message": "Customer deleted successfully"})
}
