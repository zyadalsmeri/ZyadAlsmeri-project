package routes

import (
	"aghris/config"
	"aghris/middlewares"
	"aghris/models"
	"net/http"

	"github.com/gin-gonic/gin"
)

// تعريف نموذج الإدخال للتحقق من صحة البيانات
type CategoryInput struct {
	Name string `json:"name" validate:"required"`
}

// تعريف مسارات الفئات
func CategoryRoutes(router *gin.Engine) {
	categoryRoutes := router.Group("/categories").Use(middlewares.AuthMiddleware())
	{
		categoryRoutes.POST("/", CreateCategory)
		categoryRoutes.GET("/", GetCategories)
		categoryRoutes.GET("/:id", GetCategory)
		categoryRoutes.PUT("/:id", UpdateCategory)
		categoryRoutes.DELETE("/:id", DeleteCategory)
	}
}

// ✅ إضافة فئة جديدة مع التحقق من الإدخال
func CreateCategory(c *gin.Context) {
	var input CategoryInput

	if err := c.ShouldBindJSON(&input); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": "Invalid input format"})
		return
	}

	if err := middlewares.Validate.Struct(input); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": err.Error()})
		return
	}

	category := models.Category{Name: input.Name}

	if err := config.DB.Create(&category).Error; err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "Could not create category"})
		return
	}

	c.JSON(http.StatusOK, category)
}

// ✅ جلب جميع الفئات
func GetCategories(c *gin.Context) {
	var categories []models.Category
	if err := config.DB.Find(&categories).Error; err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "Could not fetch categories"})
		return
	}
	c.JSON(http.StatusOK, categories)
}

// ✅ جلب فئة محددة
func GetCategory(c *gin.Context) {
	var category models.Category
	id := c.Param("id")

	if err := config.DB.First(&category, id).Error; err != nil {
		c.JSON(http.StatusNotFound, gin.H{"error": "Category not found"})
		return
	}

	c.JSON(http.StatusOK, category)
}

// ✅ تحديث فئة محددة مع التحقق من الإدخال
func UpdateCategory(c *gin.Context) {
	var category models.Category
	id := c.Param("id")

	if err := config.DB.First(&category, id).Error; err != nil {
		c.JSON(http.StatusNotFound, gin.H{"error": "Category not found"})
		return
	}

	var input CategoryInput
	if err := c.ShouldBindJSON(&input); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": "Invalid input format"})
		return
	}

	if err := middlewares.Validate.Struct(input); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": err.Error()})
		return
	}

	category.Name = input.Name
	if err := config.DB.Save(&category).Error; err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "Could not update category"})
		return
	}

	c.JSON(http.StatusOK, category)
}

// ✅ حذف فئة محددة
func DeleteCategory(c *gin.Context) {
	id := c.Param("id")

	if err := config.DB.Delete(&models.Category{}, id).Error; err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "Could not delete category"})
		return
	}

	c.JSON(http.StatusOK, gin.H{"message": "Category deleted successfully"})
}
