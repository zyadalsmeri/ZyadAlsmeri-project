package routes

import (
	"aghris/config"
	"aghris/models"
	"aghris/utils" // ✅ تأكد من وجود `utils/jwt.go`
	"fmt"
	"net/http"
	"time"

	"github.com/gin-gonic/gin"
	"github.com/golang-jwt/jwt/v4"
	"golang.org/x/crypto/bcrypt"
)

// **🔹 إنشاء التوكن عند تسجيل الدخول**
func GenerateToken(userID uint, role string, canCreateAdmins bool) (string, error) {
	token := jwt.NewWithClaims(jwt.SigningMethodHS256, jwt.MapClaims{
		"user_id":           userID,
		"role":              role,
		"can_create_admins": canCreateAdmins,
		"exp":               time.Now().Add(time.Hour * 24).Unix(), // صلاحية 24 ساعة
	})

	return token.SignedString([]byte(config.JWT_SECRET)) // ✅ استخدم المفتاح من `config.go`
}

// **🔹 نموذج الإدخال لتسجيل الدخول**
type LoginInput struct {
	Email    string `json:"email" validate:"required,email"`
	Password string `json:"password" validate:"required"`
}

// **🔹 تسجيل الدخول للمستخدمين (الإداريين، العملاء، الموردين)**
func Login(c *gin.Context) {
	var input LoginInput

	if err := c.ShouldBindJSON(&input); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": "Invalid JSON format"})
		return
	}

	fmt.Println("🔍 بدء تسجيل الدخول...")
	fmt.Println("📧 البريد الإلكتروني:", input.Email)

	var user interface{}
	var role string
	var canCreateAdmins bool = false

	admin := models.Admin{}
	customer := models.Customer{}
	supplier := models.Supplier{}

	if err := config.DB.Where("email = ?", input.Email).First(&admin).Error; err == nil {
		fmt.Println("✅ وجدنا إداري في قاعدة البيانات:", admin.Email)
		user = &admin
		role = "admin"
		canCreateAdmins = admin.CanCreateAdmins
	} else if err := config.DB.Where("email = ?", input.Email).First(&customer).Error; err == nil {
		fmt.Println("✅ وجدنا عميل في قاعدة البيانات:", customer.Email)
		user = &customer
		role = "customer"
	} else if err := config.DB.Where("email = ?", input.Email).First(&supplier).Error; err == nil {
		fmt.Println("✅ وجدنا مورد في قاعدة البيانات:", supplier.Email)
		user = &supplier
		role = "supplier"
	} else {
		fmt.Println("❌ لم يتم العثور على المستخدم في أي جدول.")
		c.JSON(http.StatusUnauthorized, gin.H{"error": "Invalid email or password"})
		return
	}

	// ✅ التحقق من كلمة المرور
	fmt.Println("🔑 التحقق من كلمة المرور...")

	passwordValid := false

	switch u := user.(type) {
	case *models.Admin:
		err := bcrypt.CompareHashAndPassword([]byte(u.Password), []byte(input.Password))
		passwordValid = err == nil
	case *models.Customer:
		err := bcrypt.CompareHashAndPassword([]byte(u.Password), []byte(input.Password))
		passwordValid = err == nil
	case *models.Supplier:
		err := bcrypt.CompareHashAndPassword([]byte(u.Password), []byte(input.Password))
		passwordValid = err == nil
	default:
		c.JSON(http.StatusUnauthorized, gin.H{"error": "Invalid user type"})
		return
	}

	if !passwordValid {
		fmt.Println("❌ كلمة المرور غير صحيحة!")
		c.JSON(http.StatusUnauthorized, gin.H{"error": "Invalid email or password"})
		return
	}

	fmt.Println("✅ كلمة المرور صحيحة، إنشاء التوكن...")

	// ✅ استخدام `GetID()` عند إنشاء التوكن بشكل موحّد لكل المستخدمين
	var userID uint
	switch u := user.(type) {
	case *models.Admin:
		userID = u.ID
	case *models.Customer:
		userID = u.CustomerID
	case *models.Supplier:
		userID = u.SupplierID
	}

	token, err := utils.GenerateJWT(userID, role, canCreateAdmins)
	if err != nil {
		fmt.Println("❌ فشل في إنشاء التوكن!")
		c.JSON(http.StatusInternalServerError, gin.H{"error": "Could not generate token"})
		return
	}

	fmt.Println("✅ تسجيل الدخول ناجح! إرسال التوكن...")

	c.JSON(http.StatusOK, gin.H{
		"token":             token,
		"role":              role,
		"can_create_admins": canCreateAdmins,
	})
}

// **🔹 تعريف مسارات تسجيل الدخول**
func AuthRoutes(router *gin.Engine) {
	authRoutes := router.Group("/auth")
	{
		authRoutes.POST("/login", Login) // تسجيل دخول عام للإداريين والعملاء والموردين
	}
}
