package routes

import (
	"aghris/config"
	"aghris/middlewares"
	"aghris/models"
	"aghris/utils" // ✅ تأكد من وجود `utils/jwt.go`
	"net/http"
	"strconv"

	"github.com/gin-gonic/gin"
)

// نموذج التحقق من الإدخال عند إنشاء أو تحديث الإداري
type AdminInput struct {
	Name            string `json:"name" validate:"required,min=3"`
	Username        string `json:"username" validate:"required,alphanum"`
	Email           string `json:"email" validate:"required,email"`
	Password        string `json:"password" validate:"required,min=6"`
	Mobile          string `json:"mobile" validate:"required"`
	Address         string `json:"address"`
	CanCreateAdmins bool   `json:"can_create_admins"`
}

// إنشاء إداري جديد (يتطلب صلاحيات إنشاء الإداريين)
func CreateAdmin(c *gin.Context) {
	var input AdminInput

	// التحقق من صحة البيانات
	if err := c.ShouldBindJSON(&input); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": "Invalid input"})
		return
	}

	if err := middlewares.Validate.Struct(input); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": err.Error()})
		return
	}

	admin := models.Admin{
		Name:            input.Name,
		Username:        input.Username,
		Email:           input.Email,
		Password:        input.Password,
		Mobile:          input.Mobile,
		Address:         input.Address,
		CanCreateAdmins: input.CanCreateAdmins,
	}

	// تشفير كلمة المرور قبل الحفظ
	if err := admin.HashPassword(); err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "Failed to hash password"})
		return
	}

	// حفظ الإداري في قاعدة البيانات
	if err := config.DB.Create(&admin).Error; err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "Failed to create admin"})
		return
	}

	// ✅ إنشاء توكن للمسؤول الجديد
	token, err := utils.GenerateJWT(admin.ID, "admin", admin.CanCreateAdmins)
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "Failed to generate token"})
		return
	}

	// ✅ إرسال بيانات المسؤول الجديد مع التوكن
	c.JSON(http.StatusCreated, gin.H{
		"admin": admin,
		"token": token,
	})
}

// جلب جميع الإداريين
func GetAllAdmins(c *gin.Context) {
	var admins []models.Admin
	if err := config.DB.Find(&admins).Error; err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "Failed to fetch admins"})
		return
	}
	c.JSON(http.StatusOK, admins)
}

func GetAdminByID(c *gin.Context) {
	idParam := c.Param("id")

	id, err := strconv.ParseUint(idParam, 10, 32)
	if err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": "Invalid admin ID format"})
		return
	}

	userID, exists := c.Get("user_id")
	if !exists {
		c.JSON(http.StatusUnauthorized, gin.H{"error": "Unauthorized"})
		return
	}

	userIDUint, ok := userID.(uint)
	if !ok {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "Invalid token data"})
		return
	}

	if userIDUint != uint(id) {
		c.JSON(http.StatusForbidden, gin.H{"error": "Access denied"})
		return
	}

	var admin models.Admin
	if err := config.DB.First(&admin, id).Error; err != nil {
		c.JSON(http.StatusNotFound, gin.H{"error": "Admin not found"})
		return
	}

	c.JSON(http.StatusOK, admin)
}

// تحديث بيانات إداري
func UpdateAdmin(c *gin.Context) {
	id := c.Param("id")
	var admin models.Admin

	if err := config.DB.First(&admin, id).Error; err != nil {
		c.JSON(http.StatusNotFound, gin.H{"error": "Admin not found"})
		return
	}

	var input AdminInput
	if err := c.ShouldBindJSON(&input); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": "Invalid input"})
		return
	}

	if err := middlewares.Validate.Struct(input); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": err.Error()})
		return
	}

	admin.Name = input.Name
	admin.Username = input.Username
	admin.Email = input.Email
	admin.Mobile = input.Mobile
	admin.Address = input.Address
	admin.CanCreateAdmins = input.CanCreateAdmins

	if input.Password != "" {
		admin.Password = input.Password
		if err := admin.HashPassword(); err != nil {
			c.JSON(http.StatusInternalServerError, gin.H{"error": "Failed to hash password"})
			return
		}
	}

	if err := config.DB.Save(&admin).Error; err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "Failed to update admin"})
		return
	}

	c.JSON(http.StatusOK, admin)
}

// حذف إداري
func DeleteAdmin(c *gin.Context) {
	id := c.Param("id")
	var admin models.Admin
	if err := config.DB.First(&admin, id).Error; err != nil {
		c.JSON(http.StatusNotFound, gin.H{"error": "Admin not found"})
		return
	}
	if err := config.DB.Delete(&admin).Error; err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "Failed to delete admin"})
		return
	}
	c.JSON(http.StatusOK, gin.H{"message": "Admin deleted successfully"})
}

// إضافة مسارات الإداريين إلى `router`
func AdminRoutes(router *gin.RouterGroup) {
	adminRoutes := router.Group("/admin").Use(middlewares.AuthMiddleware())
	{
		adminRoutes.POST("/create", middlewares.AdminOnlyMiddleware(), CreateAdmin)
		adminRoutes.GET("/all", GetAllAdmins)
		adminRoutes.GET("/:id", GetAdminByID)
		adminRoutes.PUT("/:id", UpdateAdmin)
		adminRoutes.DELETE("/:id", DeleteAdmin)
		adminRoutes.GET("/stats", GetAdminStats) // ✅ الآن /api/admin/stats
	}
}

func GetAdminStats(c *gin.Context) {
	var ordersCount, productsCount, usersCount int64
  
	config.DB.Model(&models.Order{}).Count(&ordersCount)
	config.DB.Model(&models.Product{}).Count(&productsCount)
	config.DB.Model(&models.Customer{}).Count(&usersCount)
  
	c.JSON(http.StatusOK, gin.H{
	  "orders":   ordersCount,
	  "products": productsCount,
	  "users":    usersCount,
	})
  }