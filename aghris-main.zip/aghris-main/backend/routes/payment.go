package routes

import (
	"aghris/config"
	"aghris/middlewares"
	"aghris/models"
	"net/http"
	"time"

	"github.com/gin-gonic/gin"
)

// ✅ تعريف مسارات إدارة الدفع
func PaymentRoutes(router *gin.Engine) {
	paymentRoutes := router.Group("/payments").Use(middlewares.AuthMiddleware())
	{
		paymentRoutes.POST("/:order_id/pay", PayOrder)
		paymentRoutes.GET("/", GetPayments)
		paymentRoutes.GET("/:id", GetPaymentDetails)
	}
}

// ✅ نموذج الإدخال لعملية الدفع
type PaymentInput struct {
	PaymentType string `json:"payment_type" validate:"required,oneof=CreditCard DebitCard PayPal"`
}

// ✅ معالجة عملية الدفع
func PayOrder(c *gin.Context) {
	orderID := c.Param("order_id")
	var order models.Order

	// ✅ التحقق من وجود الطلب
	if err := config.DB.First(&order, "order_id = ?", orderID).Error; err != nil {
		c.JSON(http.StatusNotFound, gin.H{"error": "Order not found"})
		return
	}

	// ✅ التأكد من أن الطلب لم يُدفع مسبقًا
	var existingPayment models.Payment
	if err := config.DB.Where("order_id = ?", order.OrderID).First(&existingPayment).Error; err == nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": "Order already paid"})
		return
	}

	// ✅ التحقق من الإدخال
	var input PaymentInput
	if err := c.ShouldBindJSON(&input); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": "Invalid JSON format"})
		return
	}

	if err := middlewares.Validate.Struct(input); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": err.Error()})
		return
	}

	// ✅ إنشاء سجل الدفع
	payment := models.Payment{
		OrderID:     order.OrderID,
		PaymentType: input.PaymentType,
		PaymentDate: time.Now(),
	}

	if err := config.DB.Create(&payment).Error; err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "Could not process payment"})
		return
	}

	// ✅ تحديث حالة الطلب إلى "Paid"
	order.DeliveryStatus = "Paid"
	if err := config.DB.Save(&order).Error; err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "Could not update order status"})
		return
	}

	c.JSON(http.StatusOK, gin.H{"message": "Payment successful", "payment": payment})
}

// ✅ جلب جميع عمليات الدفع
func GetPayments(c *gin.Context) {
	var payments []models.Payment
	if err := config.DB.Preload("Order").Find(&payments).Error; err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "Could not fetch payments"})
		return
	}
	c.JSON(http.StatusOK, payments)
}

// ✅ جلب تفاصيل عملية دفع معينة
func GetPaymentDetails(c *gin.Context) {
	id := c.Param("id")
	var payment models.Payment

	if err := config.DB.Preload("Order").First(&payment, "payment_id = ?", id).Error; err != nil {
		c.JSON(http.StatusNotFound, gin.H{"error": "Payment not found"})
		return
	}

	c.JSON(http.StatusOK, payment)
}
