package routes

import (
	"aghris/config"
	"aghris/middlewares"
	"aghris/models"
	"aghris/utils" // ✅ تأكد من وجود `utils/jwt.go`
	"net/http"
	"strconv"

	"github.com/gin-gonic/gin"
)

// ✅ تعريف مسارات إدارة الموردين
func SupplierRoutes(router *gin.Engine) {
	// ✅ السماح بالتسجيل بدون مصادقة
	publicRoutes := router.Group("/suppliers")
	{
		publicRoutes.POST("/register", RegisterSupplier) // ✅ تسجيل المورد متاح بدون توثيق
	}

	// ✅ حماية باقي المسارات بعد التسجيل
	authenticatedRoutes := router.Group("/suppliers").Use(middlewares.AuthMiddleware())
	{
		authenticatedRoutes.GET("/:id", GetSupplier)
		authenticatedRoutes.PUT("/:id", UpdateSupplier)
		authenticatedRoutes.DELETE("/:id", DeleteSupplier)
	}
}

// ✅ نموذج الإدخال للتحقق من صحة البيانات
type SupplierInput struct {
	SupplierName string `json:"supplier_name" validate:"required"`
	Username     string `json:"username" validate:"required,alphanum"`
	Email        string `json:"email" validate:"required,email"`
	Password     string `json:"password" validate:"required,min=6"`
	PhoneNumber  string `json:"phone_number" validate:"required"`
	IBAN         string `json:"iban" validate:"required,len=24"`
	FirstName    string `json:"first_name" validate:"required"`
	LastName     string `json:"last_name" validate:"required"`
}

// ✅ تسجيل مورد جديد
func RegisterSupplier(c *gin.Context) {
	var input SupplierInput

	if err := c.ShouldBindJSON(&input); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": "Invalid JSON format"})
		return
	}

	// ✅ التحقق من صحة الإدخال
	if err := middlewares.Validate.Struct(input); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": err.Error()})
		return
	}

	// ✅ إنشاء المورد بعد التحقق
	supplier := models.Supplier{
		SupplierName: input.SupplierName,
		Username:     input.Username,
		Email:        input.Email,
		Password:     input.Password, // سيتم تشفيرها في `BeforeCreate`
		PhoneNumber:  input.PhoneNumber,
		IBAN:         input.IBAN,
		FirstName:    input.FirstName,
		LastName:     input.LastName,
	}

	// ✅ حفظ المورد الجديد
	if err := config.DB.Create(&supplier).Error; err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "Could not register supplier"})
		return
	}

	// ✅ إنشاء توكن للمورد الجديد
	token, err := utils.GenerateJWT(supplier.SupplierID, "supplier", false)
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "Failed to generate token"})
		return
	}

	// ✅ إرسال بيانات المورد الجديد مع التوكن
	c.JSON(http.StatusOK, gin.H{
		"supplier": supplier,
		"token":    token,
	})
}

// ✅ جلب بيانات مورد محدد
func GetSupplier(c *gin.Context) {
	var supplier models.Supplier
	id := c.Param("id")

	// 🛑 الحصول على ID المستخدم من التوكن
	supplierID, exists := c.Get("user_id")
	if !exists {
		c.JSON(http.StatusUnauthorized, gin.H{"error": "Unauthorized"})
		return
	}

	// 🛑 تحويل `supplierID` من `interface{}` إلى `uint`
	supplierIDUint, ok := supplierID.(uint)
	if !ok {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "Invalid user ID format"})
		return
	}

	// 🛑 تحويل `id` من `string` إلى `uint`
	requestedID, err := strconv.ParseUint(id, 10, 32)
	if err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": "Invalid ID format"})
		return
	}

	// 🛑 التحقق مما إذا كان المورد يطلب بياناته فقط
	if uint(requestedID) != supplierIDUint {
		c.JSON(http.StatusForbidden, gin.H{"error": "Access denied"})
		return
	}

	// ✅ استرجاع بيانات المورد إذا كان يطلب بياناته فقط
	if err := config.DB.First(&supplier, id).Error; err != nil {
		c.JSON(http.StatusNotFound, gin.H{"error": "Supplier not found"})
		return
	}

	c.JSON(http.StatusOK, supplier)
}

// ✅ تعديل بيانات مورد
func UpdateSupplier(c *gin.Context) {
	id := c.Param("id")
	var supplier models.Supplier

	if err := config.DB.First(&supplier, id).Error; err != nil {
		c.JSON(http.StatusNotFound, gin.H{"error": "Supplier not found"})
		return
	}

	var input SupplierInput
	if err := c.ShouldBindJSON(&input); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": "Invalid input"})
		return
	}

	// ✅ التحقق من صحة الإدخال
	if err := middlewares.Validate.Struct(input); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": err.Error()})
		return
	}

	// ✅ تحديث البيانات
	supplier.SupplierName = input.SupplierName
	supplier.Username = input.Username
	supplier.Email = input.Email
	supplier.PhoneNumber = input.PhoneNumber
	supplier.IBAN = input.IBAN
	supplier.FirstName = input.FirstName
	supplier.LastName = input.LastName

	// ✅ تشفير كلمة المرور إذا تم تعديلها
	if input.Password != "" {
		supplier.Password = input.Password
		if err := supplier.HashPassword(); err != nil {
			c.JSON(http.StatusInternalServerError, gin.H{"error": "Failed to hash password"})
			return
		}
	}

	if err := config.DB.Save(&supplier).Error; err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "Could not update supplier"})
		return
	}

	c.JSON(http.StatusOK, supplier)
}

// ✅ حذف مورد
func DeleteSupplier(c *gin.Context) {
	id := c.Param("id")

	if err := config.DB.Delete(&models.Supplier{}, id).Error; err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "Could not delete supplier"})
		return
	}

	c.JSON(http.StatusOK, gin.H{"message": "Supplier deleted successfully"})
}
