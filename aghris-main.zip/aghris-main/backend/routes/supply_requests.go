package routes

import (
	"aghris/config"
	"aghris/middlewares"
	"aghris/models"
	"net/http"

	"github.com/gin-gonic/gin"
)

// 🔹 تعريف مسارات طلبات التوريد
func SupplyRequestRoutes(router *gin.Engine) {
	supplyRequestRoutes := router.Group("/supply-requests").Use(middlewares.AuthMiddleware())
	{
		supplyRequestRoutes.POST("/", CreateSupplyRequest)
		supplyRequestRoutes.GET("/", GetSupplyRequests)
		supplyRequestRoutes.GET("/:id", GetSupplyRequest)
		supplyRequestRoutes.PUT("/:id", UpdateSupplyRequest)
		supplyRequestRoutes.PUT("/:id/status", UpdateSupplyRequestStatus) // ✅ مضافة
		supplyRequestRoutes.DELETE("/:id", DeleteSupplyRequest)
	}
}

// 🔹 إضافة طلب توريد جديد
func CreateSupplyRequest(c *gin.Context) {
	var input struct {
		AdminID           uint    `json:"admin_id" validate:"required"`
		ProductID         uint    `json:"product_id" validate:"required"`
		RequestedQuantity int     `json:"requested_quantity" validate:"required,gte=1"`
		Price             float64 `json:"price" validate:"required,gt=0"` // ✅ مضافة
		Status            string  `json:"status"`                         // ✅ اختيارية
	}

	if err := c.ShouldBindJSON(&input); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": "Invalid JSON format"})
		return
	}

	if err := middlewares.Validate.Struct(input); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": err.Error()})
		return
	}

	supplyRequest := models.SupplyRequest{
		AdminID:           input.AdminID,
		ProductID:         input.ProductID,
		RequestedQuantity: input.RequestedQuantity,
		Price:             input.Price, // ✅ مضافة
		Status:            "Open",
	}

	if input.Status != "" {
		supplyRequest.Status = input.Status
	}

	if err := config.DB.Create(&supplyRequest).Error; err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "Could not create supply request"})
		return
	}

	c.JSON(http.StatusOK, supplyRequest)
}

// 🔹 جلب جميع طلبات التوريد
func GetSupplyRequests(c *gin.Context) {
	var supplyRequests []models.SupplyRequest
	if err := config.DB.Find(&supplyRequests).Error; err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "Could not fetch supply requests"})
		return
	}
	c.JSON(http.StatusOK, supplyRequests)
}

// 🔹 جلب تفاصيل طلب توريد معين
func GetSupplyRequest(c *gin.Context) {
	id := c.Param("id")
	var supplyRequest models.SupplyRequest

	if err := config.DB.First(&supplyRequest, id).Error; err != nil {
		c.JSON(http.StatusNotFound, gin.H{"error": "Supply request not found"})
		return
	}

	c.JSON(http.StatusOK, supplyRequest)
}

// 🔹 تحديث طلب توريد معين
func UpdateSupplyRequest(c *gin.Context) {
	id := c.Param("id")
	var supplyRequest models.SupplyRequest

	if err := config.DB.First(&supplyRequest, id).Error; err != nil {
		c.JSON(http.StatusNotFound, gin.H{"error": "Supply request not found"})
		return
	}

	var input struct {
		RequestedQuantity int     `json:"requested_quantity" validate:"required,gte=1"`
		Price             float64 `json:"price" validate:"required,gt=0"` // ✅ مضافة
	}

	if err := c.ShouldBindJSON(&input); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": "Invalid input format"})
		return
	}

	if err := middlewares.Validate.Struct(input); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": err.Error()})
		return
	}

	supplyRequest.RequestedQuantity = input.RequestedQuantity
	supplyRequest.Price = input.Price // ✅ مضافة

	if err := config.DB.Save(&supplyRequest).Error; err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "Could not update supply request"})
		return
	}

	c.JSON(http.StatusOK, supplyRequest)
}

// 🔹 تغيير حالة طلب التوريد
func UpdateSupplyRequestStatus(c *gin.Context) {
	id := c.Param("id")
	var supplyRequest models.SupplyRequest

	if err := config.DB.First(&supplyRequest, id).Error; err != nil {
		c.JSON(http.StatusNotFound, gin.H{"error": "Supply request not found"})
		return
	}

	var input struct {
		Status string `json:"status" validate:"required,oneof=Open Fulfilled Cancelled"`
	}

	if err := c.ShouldBindJSON(&input); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": "Invalid status input"})
		return
	}

	supplyRequest.Status = input.Status

	if err := config.DB.Save(&supplyRequest).Error; err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "Could not update status"})
		return
	}

	c.JSON(http.StatusOK, gin.H{"message": "Supply request status updated", "supply_request": supplyRequest})
}

// 🔹 حذف طلب توريد معين
func DeleteSupplyRequest(c *gin.Context) {
	id := c.Param("id")

	if err := config.DB.Delete(&models.SupplyRequest{}, id).Error; err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "Could not delete supply request"})
		return
	}

	c.JSON(http.StatusOK, gin.H{"message": "Supply request deleted successfully"})
}
