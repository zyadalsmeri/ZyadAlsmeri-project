package config

import (
	"aghris/models"
	"fmt"
	"log"

	"gorm.io/driver/postgres"
	"gorm.io/gorm"
)

var DB *gorm.DB

// ConnectDB يقوم بالاتصال بقاعدة البيانات
func ConnectDB() {
	dsn := "host=localhost user=postgres password=1234 dbname=aghris_db port=5432 sslmode=disable"
	database, err := gorm.Open(postgres.Open(dsn), &gorm.Config{})
	if err != nil {
		log.Fatal("❌ Failed to connect to database:", err)
	}

	// تخزين الاتصال في المتغير DB
	DB = database

	// التأكد من أن جميع الجداول متوافقة مع الموديلات الحالية
	database.AutoMigrate(
		&models.Admin{},
		&models.Customer{},
		&models.Supplier{},
		&models.Product{},
		&models.CartItem{},
		&models.Order{},
		&models.OrderItem{},
		//&models.Payment{},
		&models.Category{},
		&models.Ticket{},
		&models.SupplyRequest{},
	)

	fmt.Println("✅ Successfully connected to database and migrated models")
}
