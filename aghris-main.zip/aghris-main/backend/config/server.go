package config

import (
	"fmt"
	"log"
	"os"

	"github.com/gin-gonic/gin"
)

// ✅ تعريف `JWT_SECRET` كمفتاح ثابت
var JWT_SECRET = os.Getenv("JWT_SECRET")

// ✅ التأكد من أن `JWT_SECRET` معرف وإلا إيقاف السيرفر
func init() {
	if JWT_SECRET == "" {
		log.Fatal("❌ ERROR: JWT_SECRET is not set in environment variables! The server will not start.")
	}
}

// ✅ تهيئة السيرفر باستخدام Gin
func InitializeServer() *gin.Engine {
	router := gin.Default()

	// إضافة مسار لفحص السيرفر
	router.GET("/ping", func(c *gin.Context) {
		c.JSON(200, gin.H{"message": "pong"})
	})

	fmt.Println("🚀 Server is running on port 8080...")
	return router
}
