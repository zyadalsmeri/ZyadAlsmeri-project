package models

type Ticket struct {
	ID              uint    `json:"id" gorm:"primaryKey"`
	SupplierID      uint    `json:"supplier_id" gorm:"not null"`
	ProductID       uint    `json:"product_id" gorm:"not null"`
	TicketQuantity  int     `json:"ticket_quantity" gorm:"not null"`
	TicketPrice     float64 `json:"ticket_price"` // ❌ بدون `not null` عشان نعينه يدويًا
	AdminID         uint    `json:"admin_id" gorm:"not null"`
	Status          string  `json:"status" gorm:"default:'Pending'"`
	SupplyRequestID uint    `json:"supply_request_id" gorm:"not null"`
}

// تعيين اسم الجدول في قاعدة البيانات
func (Ticket) TableName() string {
	return "ticket"
}
