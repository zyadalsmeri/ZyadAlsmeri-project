package models

type Category struct {
	ID   uint   `json:"id" gorm:"primaryKey"`
	Name string `json:"name" gorm:"not null;unique"`
}

// تعيين اسم الجدول في قاعدة البيانات
func (Category) TableName() string {
	return "category"
}
