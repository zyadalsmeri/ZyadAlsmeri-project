// ✅ تحديث models/payment.go
package models

import "time"

type Payment struct {
	PaymentID   uint      `json:"payment_id" gorm:"primaryKey"`
	OrderID     uint      `json:"order_id" gorm:"not null"` // هذا هو المفتاح اللي يشير لـ orders
	// ❌ نحذف الربط العكسي عشان ما يخرب العلاقة
	// Order       Order     `json:"order" gorm:"foreignKey:OrderID"`
	PaymentDate time.Time `json:"payment_date" gorm:"default:CURRENT_TIMESTAMP"`
	PaymentType string    `json:"payment_type" gorm:"not null"`
}

func (Payment) TableName() string {
    return "payment"
}
