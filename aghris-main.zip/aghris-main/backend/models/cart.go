package models

import "gorm.io/gorm"

// CartItem يمثل عنصر في سلة التسوق
type CartItem struct {
	gorm.Model
	CustomerID uint `json:"customer_id" gorm:"not null"`
	ProductID  uint `json:"product_id" gorm:"not null"`
	Quantity   int  `json:"quantity" gorm:"not null;default:1"`
}

func (CartItem) TableName() string {
    return "cart_items"
}
