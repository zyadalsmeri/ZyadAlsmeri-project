package models

import "time"

type SupplyRequest struct {
	ID                uint      `json:"id" gorm:"primaryKey"`
	AdminID           uint      `json:"admin_id" gorm:"not null"`
	ProductID         uint      `json:"product_id" gorm:"not null"`
	RequestedQuantity int       `json:"requested_quantity" gorm:"not null"`
	Price             float64   `json:"price" gorm:"not null"` // ✅ السعر اللي يحدده الأدمن
	CreatedAt         time.Time `json:"created_at" gorm:"default:CURRENT_TIMESTAMP"`
	Status            string    `json:"status" gorm:"type:varchar(20);default:'Open'"` // ✅ تمت إضافته
}

// تعيين اسم الجدول في قاعدة البيانات
func (SupplyRequest) TableName() string {
	return "supply_requests"
}
