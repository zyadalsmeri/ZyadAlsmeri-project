package models

type Inventory struct {
	InventoryID       uint     `json:"inventory_id" gorm:"primaryKey"`
	ProductID         uint     `json:"product_id" gorm:"not null"`
	SupplierID        uint     `json:"supplier_id" gorm:"not null"`
	InventoryQuantity int      `json:"inventory_quantity" gorm:"not null" validate:"required,gte=0"`
	InventoryPrice    float64  `json:"inventory_price" gorm:"not null" validate:"required,gt=0"`
	Product           Product  `json:"product" gorm:"foreignKey:ProductID"`
	Supplier          Supplier `json:"supplier" gorm:"foreignKey:SupplierID"`
}

func (Inventory) TableName() string {
	return "inventory"
}
