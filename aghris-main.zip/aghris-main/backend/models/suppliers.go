package models

import (
	"golang.org/x/crypto/bcrypt"
	"gorm.io/gorm"
)

// Supplier يمثل بيانات الموردين
type Supplier struct {
	SupplierID   uint   `json:"supplier_id" gorm:"primaryKey"`
	SupplierName string `json:"supplier_name" gorm:"not null"`
	Username     string `json:"username" gorm:"unique;not null"`
	Email        string `json:"email" gorm:"unique;not null"`
	Password     string `json:"password" gorm:"not null"`
	PhoneNumber  string `json:"phone_number"`
	IBAN         string `json:"iban" gorm:"unique;not null"`
	FirstName    string `json:"first_name"`
	LastName     string `json:"last_name"`
}

// تشفير كلمة المرور
func (supplier *Supplier) HashPassword() error {
	hashedPassword, err := bcrypt.GenerateFromPassword([]byte(supplier.Password), bcrypt.DefaultCost)
	if err != nil {
		return err
	}
	supplier.Password = string(hashedPassword)
	return nil
}

// التحقق من صحة كلمة المرور
func (supplier *Supplier) CheckPassword(password string) bool {
	return bcrypt.CompareHashAndPassword([]byte(supplier.Password), []byte(password)) == nil
}

// إرجاع الـ ID للمستخدم (مهم لإنشاء التوكن)
func (supplier *Supplier) GetID() uint {
	return supplier.SupplierID
}

// تشفير كلمة المرور عند الإنشاء
func (supplier *Supplier) BeforeCreate(tx *gorm.DB) error {
	if len(supplier.Password) < 60 { // كلمة المرور المشفرة تكون دائمًا بطول 60-72
		return supplier.HashPassword()
	}
	return nil
}

func (Supplier) TableName() string {
	return "suppliers"
}
