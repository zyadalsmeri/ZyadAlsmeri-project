package models

import (
	"golang.org/x/crypto/bcrypt"
	"gorm.io/gorm"
)

// نموذج الإداريين (Admins)
type Admin struct {
	ID              uint   `json:"id" gorm:"primaryKey"`
	Name            string `json:"name" gorm:"not null"`
	Username        string `json:"username" gorm:"unique;not null"`
	Email           string `json:"email" gorm:"unique;not null"`
	Password        string `json:"password" gorm:"not null"`
	Mobile          string `json:"mobile"`
	Address         string `json:"address"`
	CanCreateAdmins bool   `json:"can_create_admins" gorm:"default:false"`
}

// تشفير كلمة المرور
func (admin *Admin) HashPassword() error {
	hashedPassword, err := bcrypt.GenerateFromPassword([]byte(admin.Password), bcrypt.DefaultCost)
	if err != nil {
		return err
	}
	admin.Password = string(hashedPassword)
	return nil
}

// التحقق من صحة كلمة المرور
func (admin *Admin) CheckPassword(password string) bool {
	err := bcrypt.CompareHashAndPassword([]byte(admin.Password), []byte(password))
	return err == nil
}

// إرجاع الـ ID للمستخدم (مهم لإنشاء التوكن)
func (admin *Admin) GetID() uint {
	return admin.ID
}

// تشفير كلمة المرور عند الإنشاء
func (admin *Admin) BeforeCreate(tx *gorm.DB) error {
	hashedPassword, err := bcrypt.GenerateFromPassword([]byte(admin.Password), bcrypt.DefaultCost)
	if err != nil {
		return err
	}
	admin.Password = string(hashedPassword)
	return nil
}

func (Admin) TableName() string {
	return "admins"
}
