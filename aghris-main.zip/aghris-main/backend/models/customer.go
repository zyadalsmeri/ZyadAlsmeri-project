package models

import (
	"golang.org/x/crypto/bcrypt"
	"gorm.io/gorm"
)

// Customer يمثل بيانات العملاء
type Customer struct {
	CustomerID uint   `json:"customer_id" gorm:"primaryKey"`
	Name       string `json:"name" gorm:"not null"`
	Username   string `json:"username" gorm:"unique;not null"`
	Email      string `json:"email" gorm:"unique;not null"`
	Password   string `json:"password" gorm:"not null"`
	Mobile     string `json:"mobile"`
	City       string `json:"city"`
	Street     string `json:"street"`
	CustomerMobile string `json:"customer_mobile" validate:"required"` // ✅ أضف هذا السطر
}

// تشفير كلمة المرور
func (customer *Customer) HashPassword() error {
	hashedPassword, err := bcrypt.GenerateFromPassword([]byte(customer.Password), bcrypt.DefaultCost)
	if err != nil {
		return err
	}
	customer.Password = string(hashedPassword)
	return nil
}

// التحقق من صحة كلمة المرور
func (customer *Customer) CheckPassword(password string) bool {
	return bcrypt.CompareHashAndPassword([]byte(customer.Password), []byte(password)) == nil
}

// إرجاع الـ ID للمستخدم (مهم لإنشاء التوكن)
func (customer *Customer) GetID() uint {
	return customer.CustomerID
}

// تشفير كلمة المرور عند الإنشاء
func (customer *Customer) BeforeCreate(tx *gorm.DB) error {
	if len(customer.Password) < 60 { // كلمة المرور المشفرة تكون دائمًا بطول 60-72
		return customer.HashPassword()
	}
	return nil
}

func (Customer) TableName() string {
	return "customers"
}
