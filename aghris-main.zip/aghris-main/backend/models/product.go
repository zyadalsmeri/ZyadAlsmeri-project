package models

import (
	"time"
)

// تعريف هيكلة المنتج
type Product struct {
	ProductID  int       `json:"product_id" gorm:"primaryKey;autoIncrement"`
	Name       string    `json:"name" gorm:"type:text;not null"`
	Price      float64   `json:"price" gorm:"type:numeric(10,2);not null"`
	Picture    string    `json:"picture" gorm:"type:text"`
	CategoryID int       `json:"category_id" gorm:"type:bigint"`
	AdminID    int       `json:"admin_id" gorm:"type:bigint"`
	CreatedAt  time.Time `json:"created_at" gorm:"autoCreateTime"`
	UpdatedAt  time.Time `json:"updated_at" gorm:"autoUpdateTime"`
}

func (Product) TableName() string {
	return "products"
}
