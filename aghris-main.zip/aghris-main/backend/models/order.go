package models

type Order struct {
	OrderID         uint        `json:"order_id" gorm:"primaryKey"`
	CustomerID      uint        `json:"customer_id" gorm:"not null"`
	CustomerName    string      `json:"customer_name" gorm:"not null"`
	CustomerAddress string      `json:"customer_address" gorm:"not null"`
	OrderDate       string      `json:"orderdate" gorm:"type:timestamp"`
	TrackingOrder   string      `json:"tracking_order" gorm:"unique"`
	DeliveryStatus  string      `json:"delivery_status" gorm:"default:'pending'"`
	TotalPrice      float64     `gorm:"column:total_price;not null" json:"total_price"`
	SupplyStatus    string      `json:"supply_status" gorm:"not null"`
	OrderItems      []OrderItem `json:"order_items" gorm:"foreignKey:OrderID"`
}

type OrderItem struct {
	OrderItemID     uint    `json:"order_item_id" gorm:"primaryKey"`
	OrderID         uint    `json:"order_id" gorm:"not null"`
	ProductID       uint    `json:"product_id" gorm:"not null"`
	ProductQuantity int     `json:"product_quantity" gorm:"not null"`
	Subtotal        float64 `json:"subtotal" gorm:"not null"`
}

func (Order) TableName() string {
	return "orders"
}

func (OrderItem) TableName() string {
	return "order_items"
}
