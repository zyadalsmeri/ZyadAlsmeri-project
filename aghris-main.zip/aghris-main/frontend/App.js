import React from 'react';
import { CartProvider } from './context/CartContext'; // ✅ تأكد أن المسار صحيح
import { NavigationContainer } from '@react-navigation/native';
import RootLayout from './_layout'; // ✅ تأكد أن `RootLayout.tsx` موجود

export default function App() {
  return (
    <CartProvider> {/* ✅ تأكد أن `CartProvider` يلف جميع الشاشات */}
      <NavigationContainer>
        <RootLayout />
      </NavigationContainer>
    </CartProvider>
  );
}
