import React, { createContext, useContext, useState, ReactNode, useEffect } from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { BASE_URL } from '@/constants/config';

type CartItem = {
  id: number;
  title: string;
  price: number;
  quantity: number;
  image: string;
};

type CartContextType = {
  cart: CartItem[];
  setCart: React.Dispatch<React.SetStateAction<CartItem[]>>;
  addToCart: (item: CartItem) => void;
  removeFromCart: (id: number) => void;
  updateCartItem: (id: number, quantity: number) => void;
  clearCart: () => void;
  fetchCart: () => Promise<void>;
  checkoutCart: () => Promise<void>;
};

const CartContext = createContext<CartContextType | undefined>(undefined);

type CartProviderProps = {
  children: ReactNode;
};

export const CartProvider: React.FC<CartProviderProps> = ({ children }) => {
  const [cart, setCart] = useState<CartItem[]>([]);

  const fetchCart = async () => {
    try {
      const token = await AsyncStorage.getItem('token');
      console.log('🔐 Token from AsyncStorage:', token);

      if (!token) {
        throw new Error("User is not authenticated");
      }

      const response = await fetch(`${BASE_URL}/cart`, {
        headers: { Authorization: `Bearer ${token}` },
      });

      if (response.status === 401) {
        await AsyncStorage.removeItem('token');
        throw new Error("Session expired. Please log in again.");
      }

      if (!response.ok) throw new Error(`HTTP Error: ${response.status}`);

      const data = await response.json();
      setCart(data);
    } catch (error) {
      console.error('❌ Error fetching cart:', error);
    }
  };

  const addToCart = async (product: CartItem) => {
    try {
      const token = await AsyncStorage.getItem('token');
      if (!token) throw new Error("User is not authenticated");

      const response = await fetch(`${BASE_URL}/cart`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify(product),
      });

      if (!response.ok) throw new Error('Failed to add to cart');

      fetchCart();
    } catch (error) {
      console.error('❌ Error adding to cart:', error);
    }
  };

  const removeFromCart = async (id: number) => {
    try {
      const token = await AsyncStorage.getItem('token');
      if (!token) throw new Error("User is not authenticated");

      const response = await fetch(`${BASE_URL}/cart/${id}`, {
        method: 'DELETE',
        headers: { Authorization: `Bearer ${token}` },
      });

      if (!response.ok) throw new Error('Failed to remove from cart');

      fetchCart();
    } catch (error) {
      console.error('❌ Error removing from cart:', error);
    }
  };

  const updateCartItem = async (id: number, quantity: number) => {
    try {
      const token = await AsyncStorage.getItem('token');
      if (!token) throw new Error("User is not authenticated");

      const response = await fetch(`${BASE_URL}/cart/${id}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({ quantity }),
      });

      if (!response.ok) throw new Error('Failed to update cart item');

      fetchCart();
    } catch (error) {
      console.error('❌ Error updating cart item:', error);
    }
  };

  const clearCart = () => {
    setCart([]);
  };

  const checkoutCart = async () => {
    try {
      const token = await AsyncStorage.getItem('token');
      if (!token) throw new Error("User is not authenticated");

      const response = await fetch(`${BASE_URL}/orders`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({ items: cart }),
      });

      if (!response.ok) throw new Error('Failed to place order');

      clearCart();
    } catch (error) {
      console.error('❌ Error placing order:', error);
    }
  };

  // ✅ جلب السلة فقط إذا فيه توكن
  useEffect(() => {
    const tryFetchCart = async () => {
      const token = await AsyncStorage.getItem('token');
      if (token) {
        await fetchCart();
      } else {
        console.log("⚠️ No token found, skipping fetchCart");
      }
    };
    tryFetchCart();
  }, []);

  return (
    <CartContext.Provider
      value={{
        cart,
        setCart,
        addToCart,
        removeFromCart,
        updateCartItem,
        clearCart,
        fetchCart,
        checkoutCart,
      }}
    >
      {children}
    </CartContext.Provider>
  );
};

export const useCart = () => {
  const context = useContext(CartContext);
  if (!context) {
    throw new Error('useCart must be used within a CartProvider');
  }
  return context;
};

export default CartProvider;
