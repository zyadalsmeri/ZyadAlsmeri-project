import React, { useState } from 'react';
import { StyleSheet, Text, TextInput, View, TouchableOpacity, Alert, ActivityIndicator } from 'react-native';
import { useRouter } from 'expo-router';

const SignUpScreen = () => {
  const router = useRouter();
  
  // ✅ تعريف القيم المدخلة
  const [firstName, setFirstName] = useState('');
  const [lastName, setLastName] = useState('');
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [phone, setPhone] = useState('');
  const [email, setEmail] = useState('');
  const [iban, setIban] = useState('');
  const [loading, setLoading] = useState(false);

  // ✅ تنفيذ تسجيل الموردين
  const handleSupplierRegister = async () => {
    if (!firstName || !lastName || !username || !password || !phone || !email || !iban) {
      Alert.alert('❌ Error', 'Please fill in all required fields.');
      return;
    }

    setLoading(true);
    try {
      const response = await fetch('https://your-api.com/auth/supplier-register', { // ✅ ضع رابط API الصحيح
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          firstName,
          lastName,
          username,
          password,
          phone,
          email,
          iban,
        }),
      });

      const data = await response.json();
      console.log('Response Status:', response.status);
      console.log('Response Data:', data);

      if (!response.ok) {
        throw new Error(data.message || '❌ Registration failed');
      }

      Alert.alert('✅ Success', 'Supplier account created successfully! Please login.');
      router.push('/screens/Login'); // ✅ تحويل المورد إلى صفحة تسجيل الدخول

    } catch (error: any) {
      Alert.alert('❌ Registration Error', error.message);
    } finally {
      setLoading(false);
    }
  
  };

  return (
    <View style={styles.container}>
      <Text style={styles.welcomeText}>Welcome to</Text>
      <Text style={styles.aghrisText}>Aghris</Text>
      <Text style={styles.createAccountText}>Create an account</Text>
      <Text style={styles.supplierText}>For Supplier</Text>
      <Text style={styles.instructionText}>Enter your Information to sign up to Aghris</Text>

      <TextInput placeholder="First name" style={styles.input} placeholderTextColor="#757575" />
      <TextInput placeholder="Last name" style={styles.input} placeholderTextColor="#757575" />
      <TextInput placeholder="Username" style={styles.input} placeholderTextColor="#757575" />
      <TextInput placeholder="Password" secureTextEntry style={styles.input} placeholderTextColor="#757575" />
      <TextInput placeholder="Number" style={styles.input} placeholderTextColor="#757575" />
      <TextInput placeholder="email@domain.com" keyboardType="email-address" style={styles.input} placeholderTextColor="#757575" />
      <TextInput placeholder="IBAN" style={styles.input} placeholderTextColor="#757575" />

      <TouchableOpacity style={styles.button}>
        <Text style={styles.buttonText}>Register</Text>
      </TouchableOpacity>

      <Text style={styles.loginText}>or</Text>
      <TouchableOpacity style={styles.button} onPress={() => router.push('/screens/Login')}>
        <Text style={styles.buttonText}>Login</Text>
      </TouchableOpacity>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f7fafc',
    padding: 20,
    justifyContent: 'center',
    borderRadius: 20,
    margin: 10,
  },
  welcomeText: {
    fontSize: 24,
    fontWeight: 'bold',
    textAlign: 'center',
  },
  aghrisText: {
    fontSize: 24,
    fontWeight: 'bold',
    textAlign: 'center',
    marginBottom: 20,
    color:'#388E3C',
  },
  createAccountText: {
    fontSize: 18,
    fontWeight: '600',
    textAlign: 'center',
    marginBottom: 10,
  },
  supplierText: {
    fontSize: 18,
    fontWeight: '600',
    textAlign: 'center',
    marginBottom: 10,
    color: 'black',
  },
  instructionText: {
    textAlign: 'center',
    marginBottom: 20,
  },
  input: {
    height: 50,
    borderColor: '#B0BEC5',
    borderWidth: 1,
    borderRadius: 10,
    paddingLeft: 15,
    marginBottom: 10,
    color: 'black',
  },
  button: {
    backgroundColor: '#000',
    borderRadius: 10,
    alignItems: 'center',
    padding: 15,
    marginBottom: 10,
  },
  buttonText: {
    color: '#FFFFFF',
    fontWeight: 'bold',
  },
  loginText: {
    textAlign: 'center',
    marginVertical: 10,
  },
});

export default SignUpScreen;