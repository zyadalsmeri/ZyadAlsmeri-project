import React, { useState, useEffect } from 'react';
import { View, Text, TouchableOpacity, StyleSheet, ScrollView, Alert, ActivityIndicator } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useRouter, useLocalSearchParams } from 'expo-router';

const AdminOrderDetailsScreen = () => {
  const router = useRouter();
  const { orderId } = useLocalSearchParams(); // ✅ جلب رقم الطلب من البارامترات
  const [order, setOrder] = useState<any>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchOrderDetails = async () => {
      try {
        // 📌 **🔴 عند توفر API، قم بإزالة التعليق أدناه لتحميل بيانات الطلب**
        /*
        const response = await fetch(`https://your-api.com/orders/${orderId}`);
        const data = await response.json();
        setOrder(data);
        */
        
        // ✅ بيانات افتراضية للاختبار
        setOrder({
          id: orderId || 12345,
          customerName: 'John Doe',
          date: '2024-03-15',
          total: 250,
          status: 'Pending',
          items: [
            { id: 1, name: 'Plant A', quantity: 2, price: 50 },
            { id: 2, name: 'Plant B', quantity: 1, price: 150 },
          ],
        });

      } catch (error) {
        Alert.alert('❌ Error', 'Failed to fetch order details');
      } finally {
        setLoading(false);
      }
    };
    fetchOrderDetails();
  }, [orderId]);

  // ✅ تحديث حالة الطلب
  const updateOrderStatus = async (newStatus: string) => {
    try {
      // 📌 **🔴 عند توفر API، قم بإزالة التعليق أدناه لتحديث حالة الطلب**
      /*
      const response = await fetch(`https://your-api.com/orders/${orderId}/update-status`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ status: newStatus }),
      });

      if (!response.ok) throw new Error('Failed to update status');
      */

      setOrder((prevOrder: any) => ({ ...prevOrder, status: newStatus }));
      Alert.alert('✅ Success', `Order status updated to ${newStatus}`);

    } catch (error) {
      Alert.alert('❌ Error', 'Could not update order status');
    }
  };

  if (loading) {
    return (
      <View style={styles.loader}>
        <ActivityIndicator size="large" color="#009961" />
      </View>
    );
  }

  return (
    <View style={styles.container}>
      {/* 🔹 شريط العنوان */}
      <View style={styles.header}>
        <TouchableOpacity onPress={() => router.back()} style={styles.backButton}>
          <Ionicons name="arrow-back" size={24} color="white" />
        </TouchableOpacity>
        <Text style={styles.headerTitle}>Order Details</Text>
        <Ionicons name="receipt-outline" size={24} color="white" />
      </View>

      <ScrollView contentContainerStyle={styles.detailsContainer}>
        {/* 🔹 معلومات الطلب */}
        <View style={styles.card}>
          <Text style={styles.sectionTitle}>Order Info</Text>
          <Text style={styles.infoText}>📌 Order ID: {order?.id}</Text>
          <Text style={styles.infoText}>👤 Customer: {order?.customerName}</Text>
          <Text style={styles.infoText}>📅 Date: {order?.date}</Text>
          <Text style={styles.infoText}>💰 Total: {order?.total} SR</Text>
          <Text style={[styles.statusText, getStatusStyle(order?.status)]}>📦 {order?.status}</Text>
        </View>

        {/* 🔹 قائمة المنتجات */}
        <View style={styles.card}>
          <Text style={styles.sectionTitle}>Products</Text>
          {order?.items.map((item: any) => (
            <View key={item.id} style={styles.productRow}>
              <Text style={styles.productName}>{item.name}</Text>
              <Text style={styles.productQty}>x{item.quantity}</Text>
              <Text style={styles.productPrice}>{item.price} SR</Text>
            </View>
          ))}
        </View>

        {/* 🔹 زر تحديث حالة الطلب */}
        <View style={styles.card}>
          <Text style={styles.sectionTitle}>Update Status</Text>
          <View style={styles.statusButtons}>
            {['Processing', 'Shipped', 'Delivered'].map((status) => (
              <TouchableOpacity
                key={status}
                style={[styles.statusButton, order?.status === status && styles.activeStatus]}
                onPress={() => updateOrderStatus(status)}
              >
                <Text style={styles.statusButtonText}>{status}</Text>
              </TouchableOpacity>
            ))}
          </View>
        </View>
      </ScrollView>
    </View>
  );
};

// ✅ **حالة الألوان حسب حالة الطلب**
const getStatusStyle = (status: string) => {
  switch (status) {
    case 'Pending':
      return { color: '#FFA500' };
    case 'Processing':
      return { color: '#1E90FF' };
    case 'Shipped':
      return { color: '#007BFF' };
    case 'Delivered':
      return { color: '#28A745' };
    default:
      return { color: '#333' };
  }
};

// ✅ **التنسيق**
const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F3F4F6',
  },
  loader: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  header: {
    backgroundColor: '#009961',
    paddingVertical: 20,
    paddingHorizontal: 20,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    borderBottomLeftRadius: 20,
    borderBottomRightRadius: 20,
    elevation: 4,
  },
  headerTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: 'white',
  },
  backButton: {
    padding: 5,
  },
  detailsContainer: {
    padding: 20,
    alignItems: 'center',
  },
  card: {
    backgroundColor: 'white',
    width: '90%',
    padding: 15,
    borderRadius: 12,
    marginBottom: 15,
    elevation: 3,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 10,
    color: '#333',
  },
  infoText: {
    fontSize: 16,
    color: '#555',
    marginBottom: 5,
  },
  statusText: {
    fontSize: 16,
    fontWeight: 'bold',
    marginTop: 10,
  },
  productRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 10,
    paddingBottom: 5,
    borderBottomWidth: 1,
    borderBottomColor: '#EEE',
  },
  productName: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#333',
  },
  productQty: {
    fontSize: 16,
    color: '#555',
  },
  productPrice: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#009961',
  },
  statusButtons: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  statusButton: {
    backgroundColor: '#DDD',
    paddingVertical: 10,
    paddingHorizontal: 15,
    borderRadius: 8,
    marginRight: 5,
  },
  activeStatus: {
    backgroundColor: '#009961',
  },
  statusButtonText: {
    color: 'white',
    fontSize: 14,
    fontWeight: 'bold',
  },
});

export default AdminOrderDetailsScreen;
