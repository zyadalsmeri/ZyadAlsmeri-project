import React, { useState } from 'react';
import { StyleSheet, Text, TextInput, View, TouchableOpacity, Alert, ActivityIndicator } from 'react-native';
import { useRouter } from 'expo-router';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { BASE_URL } from '@/constants/config'; // ✅ تم استيراد BASE_URL

const SignUpScreen = () => {
  const router = useRouter();
  
  const [firstName, setFirstName] = useState('');
  const [lastName, setLastName] = useState('');
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [city, setCity] = useState('');
  const [street, setStreet] = useState('');
  const [phone, setPhone] = useState('');
  const [email, setEmail] = useState('');
  const [loading, setLoading] = useState(false);

  const handleRegister = async () => {
    if (!firstName || !lastName || !username || !password || !email || !city || !street || !phone) {
      Alert.alert('❌ Error', 'Please fill in all required fields.');
      return;
    }
  
    if (!/^\d{10}$/.test(phone)) {
      Alert.alert('❌ Error', 'Phone number must be exactly 10 digits.');
      return;
    }
  
    setLoading(true);
    try {
      const response = await fetch(`${BASE_URL}/customers/register`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          Name: `${firstName} ${lastName}`,
          Username: username,
          Email: email,
          Password: password,
          City: city,
          Street: street,
          customer_mobile: phone.trim()
        }),
      });
  
      const data = await response.json();
  
      if (!response.ok) {
        throw new Error(data.message || 'Registration failed');
      }
  
      if (!data.token) { // ✅ التأكد من أن التوكن تم استلامه
        throw new Error("Registration successful, but token is missing.");
      }
  
      await AsyncStorage.setItem('token', data.token);
      Alert.alert('✅ Success', 'Account created successfully!');
      router.replace('/screens/HomeScreen');
  
    }
    
    catch (error: unknown) { // ✅ تأكد من أن TypeScript يعرف أن `error` يمكن أن يكون أي نوع
      let errorMessage = 'An unknown error occurred';
    
      if (error instanceof Error) { // ✅ تحقق مما إذا كان `error` كائن من نوع `Error`
        errorMessage = error.message;
      }
    
      Alert.alert('❌ Login Error', errorMessage);
    }
    
    
    
    finally {
      setLoading(false);
    }
  };
  
  
  

  return (
    <View style={styles.container}>
      <Text style={styles.welcomeText}>Welcome to</Text>
      <Text style={styles.aghrisText}>Aghris</Text>
      <Text style={styles.createAccountText}>Create an account</Text>
      <Text style={styles.instructionText}>Enter your Information to sign up</Text>

      <TextInput placeholder="First name" style={styles.input} placeholderTextColor="#757575" value={firstName} onChangeText={setFirstName} />
      <TextInput placeholder="Last name" style={styles.input} placeholderTextColor="#757575" value={lastName} onChangeText={setLastName} />
      <TextInput placeholder="Username" style={styles.input} placeholderTextColor="#757575" value={username} onChangeText={setUsername} />
      <TextInput placeholder="Password" secureTextEntry style={styles.input} placeholderTextColor="#757575" value={password} onChangeText={setPassword} />
      <TextInput placeholder="City" style={styles.input} placeholderTextColor="#757575" value={city} onChangeText={setCity} />
      <TextInput placeholder="Street" style={styles.input} placeholderTextColor="#757575" value={street} onChangeText={setStreet} />
      <TextInput placeholder="Number" style={styles.input} placeholderTextColor="#757575" value={phone} onChangeText={setPhone} />
      <TextInput placeholder="Email" keyboardType="email-address" style={styles.input} placeholderTextColor="#757575" value={email} onChangeText={setEmail} />

      <TouchableOpacity style={styles.button} onPress={handleRegister} disabled={loading}>
        {loading ? <ActivityIndicator color="#fff" /> : <Text style={styles.buttonText}>Register</Text>}
      </TouchableOpacity>

      <Text style={styles.supplierText}>
        If you are a supplier <Text style={styles.linkText} onPress={() => router.push('/screens/supplier-register')}>click here</Text>
      </Text>
      <Text style={styles.loginText}>or</Text>
      <TouchableOpacity style={styles.button} onPress={() => router.push('/screens/Login')}>
        <Text style={styles.buttonText}>Login</Text>
      </TouchableOpacity>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f7fafc',
    padding: 20,
    justifyContent: 'center',
    borderRadius: 20,
    margin: 10,
  },
  welcomeText: {
    fontSize: 24,
    fontWeight: 'bold',
    textAlign: 'center',
  },
  aghrisText: {
    fontSize: 24,
    fontWeight: 'bold',
    textAlign: 'center',
    marginBottom: 20,
    color:'#388E3C',
  },
  createAccountText: {
    fontSize: 18,
    fontWeight: '600',
    textAlign: 'center',
    marginBottom: 10,
  },
  instructionText: {
    textAlign: 'center',
    marginBottom: 20,
  },
  input: {
    height: 50,
    borderColor: '#B0BEC5',
    borderWidth: 1,
    borderRadius: 10,
    paddingLeft: 15,
    marginBottom: 10,
    color: 'black',
  },
  button: {
    backgroundColor: '#000',
    borderRadius: 10,
    alignItems: 'center',
    padding: 15,
    marginBottom: 10,
  },
  buttonText: {
    color: '#FFFFFF',
    fontWeight: 'bold',
  },
  supplierText: {
    textAlign: 'center',
    marginBottom: 10,
  },
  linkText: {
    color: '#3D5AFE',
    textDecorationLine: 'underline',
  },
  loginText: {
    textAlign: 'center',
    marginVertical: 10,
  },
});

export default SignUpScreen;
