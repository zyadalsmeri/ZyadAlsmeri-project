import React, { useState } from 'react';
import {
  View,
  Text,
  TouchableOpacity,
  Image,
  StyleSheet,
  FlatList,
  Dimensions,
  Platform,
} from 'react-native';
import { FontAwesome } from '@expo/vector-icons';
import { LinearGradient } from 'expo-linear-gradient';
import { useRouter } from 'expo-router'; // ✅ استدعاء Expo Router
import CurvedButton from '@/components/CurvedButton';

const screenWidth = Dimensions.get('window').width;
const CARD_WIDTH = screenWidth / 2 - 25;

const plantData = [
  { name: 'The Friendly Fern', image: 'https://placehold.co/150x150', value: 10 },
  { name: 'The Potted Head', image: 'https://placehold.co/150x150', value: 20 },
  { name: 'Ledger Block', image: 'https://placehold.co/150x150', value: 30 },
  { name: 'Mini Cacti', image: 'https://placehold.co/150x150', value: 120 },
];

const Plants = () => {
  const [counts, setCounts] = useState([0, 0, 0, 0]);
  const router = useRouter(); // ✅ التوجيه

  const incrementCount = (index: number) => {
    const newCounts = [...counts];
    newCounts[index]++;
    setCounts(newCounts);
  };

  const decrementCount = (index: number) => {
    const newCounts = [...counts];
    if (newCounts[index] > 0) {
      newCounts[index]--;
    }
    setCounts(newCounts);
  };

  const renderItem = ({ item, index }: any) => (
    <View style={styles.cardWrapper}>
      <Text style={styles.valueText}>{item.value}</Text>

      <LinearGradient
        colors={['#e0f2ff', '#ffffff']}
        style={styles.card}
        start={{ x: 0.5, y: 0 }}
        end={{ x: 0.5, y: 1 }}
      >
        <View style={styles.cardContent}>
          <Image source={{ uri: item.image }} style={styles.image} />
          <Text style={styles.plantName}>{item.name}</Text>

          <View style={styles.counterContainer}>
            <CurvedButton onPress={() => decrementCount(index)} icon="-" reversed />
            <Text style={styles.counterText}>{counts[index].toString().padStart(2, '0')}</Text>
            <CurvedButton onPress={() => incrementCount(index)} icon="+" />
          </View>

          <View style={styles.bottomOverlay}>
            <TouchableOpacity style={styles.supplyButton}>
              <Text style={styles.supplyButtonText}>Supply</Text>
            </TouchableOpacity>
          </View>
        </View>
      </LinearGradient>
    </View>
  );

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.headerText}>List of requests</Text>
        <View style={styles.headerIcons}>
          {/* ✅ زر البروفايل */}
          <TouchableOpacity onPress={() => router.push('../screens/SupplierProfileScreen')}>
            <FontAwesome name="user-circle" size={24} color="green" style={{ marginRight: 10 }} />
          </TouchableOpacity>
          <FontAwesome name="bars" size={24} color="black" />
        </View>
      </View>

      <View style={styles.subHeader}>
        <Text style={styles.subHeaderText}>Plant Collections</Text>
        <FontAwesome name="arrow-right" size={24} color="black" />
      </View>

      <FlatList
        data={plantData}
        renderItem={renderItem}
        keyExtractor={(_, index) => index.toString()}
        numColumns={2}
        columnWrapperStyle={styles.row}
        contentContainerStyle={styles.gridContainer}
        showsVerticalScrollIndicator={false}
      />
    </View>
  );
};

export default Plants;


const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f3f4f6',
    paddingTop: 50,
    paddingHorizontal: 15,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 15,
  },
  headerText: {
    fontSize: 24,
    fontWeight: 'bold',
    fontStyle: 'italic',
  },
  headerIcons: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  subHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 15,
  },
  subHeaderText: {
    fontSize: 18,
    fontWeight: '600',
  },
  gridContainer: {
    paddingBottom: 20,
  },
  row: {
    justifyContent: 'space-between',
    marginBottom: 25,
  },
  cardWrapper: {
    width: CARD_WIDTH,
    alignItems: 'center',
  },
  valueText: {
    fontSize: 12,
    fontWeight: 'bold',
    marginBottom: 5,
  },
  card: {
    borderRadius: 30,
    overflow: 'hidden',
    width: '100%',
    ...Platform.select({
      android: { elevation: 6 },
      ios: {
        shadowColor: '#000',
        shadowOpacity: 0.1,
        shadowRadius: 6,
        shadowOffset: { width: 0, height: 4 },
      },
    }),
  },
  cardContent: {
    alignItems: 'center',
    paddingTop: 20,
    paddingBottom: 10,
    backgroundColor: 'transparent',
  },
  image: {
    width: 90,
    height: 90,
    resizeMode: 'contain',
    marginBottom: 10,
  },
  plantName: {
    fontSize: 14,
    fontWeight: '600',
    textAlign: 'center',
    marginBottom: 10,
  },
  counterContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 10,
  },
  counterText: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#000',
    marginHorizontal: 10,
  },
  bottomOverlay: {
    backgroundColor: '#fff',
    width: '100%',
    borderBottomLeftRadius: 30,
    borderBottomRightRadius: 30,
    paddingVertical: 15,
    alignItems: 'center',
  },
  supplyButton: {
    backgroundColor: '#000',
    borderRadius: 50,
    paddingVertical: 8,
    paddingHorizontal: 35,
  },
  supplyButtonText: {
    color: '#fff',
    fontSize: 14,
    fontWeight: '600',
  },
});
