import React, { useEffect, useState } from 'react';
import { View, Text, Image, StyleSheet, ScrollView, TouchableOpacity, ActivityIndicator, FlatList, Alert } from 'react-native';
import { FontAwesome } from '@expo/vector-icons';
import { useRouter } from 'expo-router';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { BASE_URL } from '@/constants/config'; // ✅ تم استيراد `BASE_URL`

// ✅ تعريف نوع الطلب والمنتج داخل الطلب
type OrderItem = {
  id: number;
  title: string;
  quantity: number;
  price: number;
  image: string;
};

type Order = {
  id: number;
  status: string;
  date: string;
  estimatedDelivery: string;
  items: OrderItem[];
};

const TrackOrderScreen = () => {
  const router = useRouter();
  const [orders, setOrders] = useState<Order[]>([]);
  const [loading, setLoading] = useState(true);

  // ✅ 1. جلب الطلبات من API
  const fetchOrders = async () => {
    try {
      const token = await AsyncStorage.getItem('token');
      if (!token) throw new Error('User is not authenticated');

      const response = await fetch(`${BASE_URL}/orders`, {
        headers: { Authorization: `Bearer ${token}` },
      });

      if (!response.ok) {
        throw new Error(`HTTP Error: ${response.status}`);
      }

      const data = await response.json();
      setOrders(data as Order[]); // ✅ حل مشكلة `never`
    } catch (error) {
      console.error("❌ Error fetching orders:", error);
      Alert.alert('❌ Error', 'Failed to fetch orders.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchOrders();
  }, []);

  return (
    <ScrollView contentContainerStyle={styles.scrollContainer}>
      <View style={styles.container}>
        <View style={styles.headerContainer}>
          <Text style={styles.header}>Order Tracking</Text>
        </View>

        {loading ? (
          <ActivityIndicator size="large" color="#007bff" />
        ) : orders.length === 0 ? (
          <Text style={styles.emptyMessage}>No orders found.</Text>
        ) : (
          orders.map((order) => (
            <View key={order.id} style={styles.card}>
              <View style={styles.orderInfo}>
                <Text style={styles.orderId}>Order ID: {order.id}</Text>
                <View style={styles.orderDateContainer}>
                  <Text style={styles.orderDateLabel}>Order date:</Text>
                  <Text style={styles.orderDate}>{order.date}</Text>
                </View>
                <View style={styles.estimatedDeliveryContainer}>
                  <FontAwesome name="truck" size={16} color="green" />
                  <Text style={styles.estimatedDelivery}>
                    Estimated delivery: {order.estimatedDelivery}
                  </Text>
                </View>
              </View>

              {/* ✅ حالة الطلب */}
              <Text style={styles.statusLabel}>Status: {order.status}</Text>

              {/* ✅ المنتجات داخل الطلب */}
              <FlatList
                data={order.items}
                keyExtractor={(item) => item.id.toString()}
                renderItem={({ item }) => (
                  <View style={styles.item}>
                    <Image source={{ uri: item.image }} style={styles.itemImage} />
                    <View style={styles.itemInfo}>
                      <Text style={styles.itemName}>{item.title}</Text>
                      <Text style={styles.itemQuantity}>x{item.quantity}</Text>
                    </View>
                    <Text style={styles.itemPrice}>{item.price} R.S</Text>
                  </View>
                )}
              />

              {/* ✅ زر الرجوع */}
              <TouchableOpacity style={styles.backButton} onPress={() => router.back()}>
                <Text style={styles.backButtonText}>Back</Text>
              </TouchableOpacity>
            </View>
          ))
        )}
      </View>
    </ScrollView>
  );
};

// ✅ **الحفاظ على نفس الستايل والتصميم بدون تغيير**
const styles = StyleSheet.create({
  scrollContainer: {
    flexGrow: 1,
    padding: 16,
    backgroundColor: '#f3f4f6',
  },
  container: {
    flex: 1,
  },
  headerContainer: {
    alignItems: 'center',
    marginBottom: 16,
  },
  header: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#374151',
  },
  card: {
    backgroundColor: '#fff',
    borderRadius: 8,
    padding: 16,
    marginBottom: 16,
    shadowColor: '#000',
    shadowOpacity: 0.1,
    shadowRadius: 10,
    shadowOffset: { width: 0, height: 5 },
    elevation: 5,
  },
  orderInfo: {
    marginBottom: 16,
  },
  orderId: {
    fontSize: 18,
    fontWeight: '600',
  },
  orderDateContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginTop: 8,
  },
  orderDateLabel: {
    color: '#6b7280',
  },
  orderDate: {
    fontWeight: '600',
    marginLeft: 4,
  },
  estimatedDeliveryContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginTop: 4,
  },
  estimatedDelivery: {
    color: 'green',
    fontWeight: '600',
    marginLeft: 4,
  },
  statusLabel: {
    fontWeight: 'bold',
    color: '#333',
    marginBottom: 10,
  },
  item: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 16,
  },
  itemImage: {
    width: 50,
    height: 50,
    borderRadius: 25,
  },
  itemInfo: {
    flex: 1,
    marginLeft: 16,
  },
  itemName: {
    fontWeight: 'bold',
  },
  itemQuantity: {
    color: '#6b7280',
  },
  itemPrice: {
    fontWeight: 'bold',
  },
  backButton: {
    backgroundColor: '#000',
    paddingVertical: 12,
    borderRadius: 4,
    alignItems: 'center',
    marginTop: 10,
  },
  backButtonText: {
    color: '#fff',
    fontWeight: 'bold',
  },
  emptyMessage: {
    textAlign: 'center',
    color: '#6b7280',
    fontSize: 16,
    marginTop: 20,
  },
});

export default TrackOrderScreen;
