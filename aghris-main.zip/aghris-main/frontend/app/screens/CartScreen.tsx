import React, { useState, useRef, useEffect, useCallback } from 'react';
import { 
  View, Text, StyleSheet, Image, PanResponder, Animated, Alert, Dimensions, TouchableOpacity, ScrollView, ActivityIndicator
} from 'react-native';
import { useRouter } from 'expo-router';
import { useCart } from '../context/CartContext';
import { useFocusEffect } from '@react-navigation/native';
import { BASE_URL } from '@/constants/config'; // ✅ استيراد API URL
import AsyncStorage from '@react-native-async-storage/async-storage';

const { width } = Dimensions.get('window');

const CartScreen = () => {
  const pan = useRef(new Animated.ValueXY()).current;
  const [confirmed, setConfirmed] = useState(false);
  const router = useRouter();
  const { cart, setCart, removeFromCart, updateCartItem, checkoutCart } = useCart();
  const [loading, setLoading] = useState(true); // ✅ عرض اللودينج أثناء تحميل البيانات

  // ✅ جلب بيانات السلة من API عند فتح الصفحة
  useFocusEffect(
    useCallback(() => {

      const fetchCart = async () => {
        const token = await AsyncStorage.getItem('token');
if (!token) {
  console.log('🚫 No token, skipping fetchCart');
  return;
}
        try {
          const response = await fetch(`${BASE_URL}/cart`, {
            method: 'GET',
            headers: {
              'Authorization': `Bearer ${await AsyncStorage.getItem('token')}`,
              'Content-Type': 'application/json'
            }
          });

          const data = await response.json();
          if (!response.ok) {
            throw new Error(data.message || 'Failed to fetch cart');
          }

          setCart(data); // ✅ تحديث حالة السلة بالبيانات القادمة من API
        } catch (error) {
          console.error("❌ Error fetching cart:", error);
        } finally {
          setLoading(false);
        }
      };

      fetchCart();
    }, [])
  );

  // ✅ إعداد سحب الدفع
  const panResponder = PanResponder.create({
    onStartShouldSetPanResponder: () => true,
    onPanResponderMove: Animated.event([null, { dx: pan.x }], { useNativeDriver: false }),
    onPanResponderRelease: async (e, gesture) => {
      if (gesture.dx > width * 0.4) {
        setConfirmed(true);
        await handleConfirmOrder();
      }
      Animated.spring(pan, { toValue: { x: 0, y: 0 }, useNativeDriver: false }).start();
    },
  });

  // ✅ إرسال الطلب إلى API
  const handleConfirmOrder = async () => {
    try {
      const response = await fetch(`${BASE_URL}/checkout`, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${await AsyncStorage.getItem('token')}`,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({ items: cart })
      });

      const data = await response.json();
      if (!response.ok) {
        throw new Error(data.message || 'Failed to checkout');
      }

      Alert.alert(
        '✅ Payment Confirmed',
        'Your order has been successfully placed.',
        [{ text: 'OK', onPress: () => router.push('/screens/TrackOrderScreen') }]
      );
      setCart([]); // ✅ تفريغ السلة بعد الدفع
    } catch (error) {
      Alert.alert('❌ Error', 'Something went wrong, please try again.');
    }
  };

  // ✅ تحديث الكمية
  const handleUpdateQuantity = (id: number, quantity: number) => {
    if (quantity <= 0) {
      removeFromCart(id);
    } else {
      updateCartItem(id, quantity);
    }
  };

  return (
    <View style={styles.container}>
      <View style={styles.card}>
        <View style={styles.header}>
          <Text style={styles.title}>Cart</Text>
          <View style={styles.cartCount}>
            <Text style={styles.cartCountText}>{cart.length}</Text>
          </View>
        </View>

        {/* ✅ عرض اللودينج أثناء تحميل البيانات */}
        {loading ? (
          <ActivityIndicator size="large" color="#009961" />
        ) : (
          <ScrollView style={styles.items}>
            {cart.length > 0 ? (
              cart.map((item, index) => (
                <View key={index} style={styles.item}>
                  <Image style={styles.itemImage} source={{ uri: item.image }} />
                  <View>
                    <Text style={styles.itemTitle}>{item.title}</Text>
                    <Text style={styles.itemSubtitle}>{item.quantity} piece(s)</Text>
                  </View>
                  <Text style={styles.itemPrice}>{item.price} R.S</Text>
                  <TouchableOpacity onPress={() => removeFromCart(item.id)}>
                    <Text style={styles.removeButton}>❌</Text>
                  </TouchableOpacity>
                </View>
              ))
            ) : (
              <Text style={styles.emptyCartText}>🛒 Your cart is empty</Text>
            )}
          </ScrollView>
        )}
      </View>

      {/* ✅ شريط الدفع بالسحب */}
      <View style={styles.summary}>
        <View style={styles.summaryRow}>
          <Text style={styles.summaryText}>Delivery Amount</Text>
          <Text style={styles.summaryText}>25 R.S</Text>
        </View>
        <View style={styles.summaryRow}>
          <Text style={styles.summaryText}>Total Amount</Text>
          <Text style={styles.summaryText}>
            {cart.reduce((total, item) => total + item.price * item.quantity, 0)} R.S
          </Text>
        </View>

        <View style={styles.sliderContainer}>
          <Animated.View
            {...panResponder.panHandlers}
            style={[styles.slider, { transform: [{ translateX: pan.x }] }]}
          >
            <Text style={styles.sliderText}>→</Text>
          </Animated.View>
          <Text style={styles.sliderLabel}>{confirmed ? "Payment Confirmed" : "Slide to Confirm"}</Text>
        </View>
      </View>
    </View>
  );
};

export default CartScreen;



// ✅ **التنسيق**
const styles = StyleSheet.create({
  loader: {
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
  },
  
  itemDetails: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#ebf8ff',
    padding: 10,
    borderRadius: 10,
    marginBottom: 10,
  },
  quantityContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  quantityButton: {
    backgroundColor: '#38a169',
    padding: 5,
    borderRadius: 5,
  },
  itemQuantity: {
    marginHorizontal: 10,
    fontWeight: 'bold',
  },
  
  container: {
    flex: 1,
    backgroundColor: '#f7fafc',
  },
  card: {
    flex: 1,
    backgroundColor: 'white',
    borderRadius: 30,
    padding: 20,
    marginTop: 50,
    marginBottom: 100,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 8,
    elevation: 5,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 20,
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
  },
  cartCount: {
    backgroundColor: '#38a169',
    borderRadius: 20,
    width: 30,
    height: 30,
    justifyContent: 'center',
    alignItems: 'center',
  },
  cartCountText: {
    color: 'white',
    fontWeight: 'bold',
  },
  items: {
    flexGrow: 1,
  },
  item: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#ebf8ff',
    padding: 10,
    borderRadius: 10,
    marginBottom: 10,
  },
  itemImage: {
    width: 50,
    height: 50,
    borderRadius: 25,
    marginRight: 10,
  },
  itemTitle: {
    fontWeight: 'bold',
  },
  itemSubtitle: {
    color: '#718096',
  },
  itemPrice: {
    marginLeft: 'auto',
    fontWeight: 'bold',
  },
  removeButton: {
    color: 'red',
    marginLeft: 10,
    fontWeight: 'bold',
  },
  summary: {
    position: 'absolute',
    bottom: 0,
    width: '100%',
    backgroundColor: '#38a169',
    borderTopLeftRadius: 30,
    borderTopRightRadius: 30,
    padding: 20,
  },
  summaryRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 10,
  },
  summaryText: {
    color: 'white',
  },
  sliderContainer: {
    position: 'relative',
    width: '100%',
    height: 50,
    backgroundColor: 'white',
    borderRadius: 25,
    overflow: 'hidden',
    justifyContent: 'center',
    alignItems: 'center',
    marginTop: 10,
  },
  slider: {
    position: 'absolute',
    top: 0,
    left: 0,
    width: 50,
    height: 50,
    backgroundColor: '#38a169',
    borderRadius: 25,
    justifyContent: 'center',
    alignItems: 'center',
  },
  sliderText: {
    color: 'white',
    fontSize: 18,
  },
  sliderLabel: {
    color: '#38a169',
    fontWeight: 'bold',
    marginTop: 5,
  },
  emptyCartText: {
    textAlign: 'center',
    fontSize: 16,
    color: '#718096',
    marginTop: 20,
  },
});
