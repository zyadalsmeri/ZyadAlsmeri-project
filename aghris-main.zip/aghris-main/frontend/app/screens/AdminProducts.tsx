import React, { useState, useEffect } from "react";
import {
  View, Text, FlatList, TextInput, Alert, TouchableOpacity, StyleSheet, Image, ActivityIndicator, Modal,
} from "react-native";
import { BASE_URL } from "@/constants/config";
import AsyncStorage from "@react-native-async-storage/async-storage";

interface Product {
  product_id: number;
  name: string;
  price: number;
  quantity: number;
  picture: string;
  category_id: number;
  admin_id: number;
}

const AdminProducts = () => {
  const [products, setProducts] = useState<Product[]>([]);
  const [modalVisible, setModalVisible] = useState(false);
  const [editingProduct, setEditingProduct] = useState<Product | null>(null);
  const [searchQuery, setSearchQuery] = useState("");
  const [loading, setLoading] = useState(true);

  const [name, setName] = useState("");
  const [price, setPrice] = useState("");
  const [image, setImage] = useState("");
  const [quantity, setQuantity] = useState("");
  const [categoryId, setCategoryId] = useState("");

  const fetchProducts = async () => {
    try {
      setLoading(true);
      const token = await AsyncStorage.getItem("token");

      console.log("📦 Token used for admin fetch:", token);

      if (!token) throw new Error("User is not authenticated");

      const response = await fetch(`${BASE_URL}/admin/products`, {
        headers: { Authorization: `Bearer ${token}` },
      });

      const responseData = await response.text();
      if (!response.ok) throw new Error(`API Error: ${response.status} - ${responseData}`);

      const data = JSON.parse(responseData);
      const formattedData = data.products.map((p: any) => ({
        product_id: p.product_id,
        name: p.name,
        price: p.price,
        quantity: p.quantity,
        picture: p.picture,
        category_id: p.category_id,
        admin_id: p.admin_id,
      }));
      setProducts(formattedData);
    } catch (error: any) {
      Alert.alert("❌ Error Fetching Products", error.message);
    } finally {
      setLoading(false);
    }
  };

  const handleSave = async () => {
    try {
      const token = await AsyncStorage.getItem("token");
      if (!token) throw new Error("User is not authenticated");

      const adminId = 1; // ← لاحقاً خذها من التوكن
      const productData = {
        name: name,
        price: parseFloat(price),
        picture: image,
        quantity: parseInt(quantity),
        category_id: parseInt(categoryId),
        admin_id: adminId,
      };

      let response;
      if (editingProduct) {
        response = await fetch(`${BASE_URL}/admin/products/${editingProduct.product_id}`, {
          method: "PUT",
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${token}`,
          },
          body: JSON.stringify(productData),
        });
      } else {
        response = await fetch(`${BASE_URL}/admin/products`, {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${token}`,
          },
          body: JSON.stringify(productData),
        });
      }

      if (!response.ok) throw new Error("Failed to save product");

      fetchProducts();
      setModalVisible(false);
      resetForm();
    } catch (error) {
      Alert.alert("❌ Error", "Failed to save product.");
    }
  };

  const resetForm = () => {
    setName("");
    setPrice("");
    setQuantity("");
    setCategoryId("");
    setImage("");
    setEditingProduct(null);
  };

  const handleDelete = (id: number) => {
    Alert.alert("Delete Confirmation", "Are you sure you want to delete this product?", [
      { text: "Cancel", style: "cancel" },
      {
        text: "Delete",
        onPress: async () => {
          try {
            const token = await AsyncStorage.getItem("token");
            if (!token) throw new Error("User is not authenticated");

            const response = await fetch(`${BASE_URL}/admin/products/${id}`, {
              method: "DELETE",
              headers: { Authorization: `Bearer ${token}` },
            });

            if (!response.ok) throw new Error("Failed to delete product");

            fetchProducts();
          } catch (error) {
            Alert.alert("❌ Error", "Failed to delete product.");
          }
        },
      },
    ]);
  };

  useEffect(() => {
    const checkAndFetch = async () => {
      const token = await AsyncStorage.getItem("token");
      console.log("🔐 Token before fetch:", token);
      if (!token) {
        Alert.alert("❌ Unauthorized", "Please login first.");
        return;
      }
      fetchProducts();
    };
    checkAndFetch();
  }, []);

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.headerTitle}>Manage Products</Text>
      </View>

      <View style={styles.searchContainer}>
        <TextInput
          placeholder="🔍 Search for a product..."
          value={searchQuery}
          onChangeText={setSearchQuery}
          style={styles.input}
        />
      </View>

      <TouchableOpacity style={styles.addButton} onPress={() => setModalVisible(true)}>
        <Text style={styles.addButtonText}>+ Add New Product</Text>
      </TouchableOpacity>

      {loading ? (
        <ActivityIndicator size="large" color="#009961" />
      ) : (
        <FlatList
          contentContainerStyle={styles.productsContainer}
          data={products.filter((item) =>
            item.name.toLowerCase().includes(searchQuery.toLowerCase())
          )}
          keyExtractor={(item) => item.product_id.toString()}
          renderItem={({ item }) => (
            <View style={styles.productCard}>
              <Image source={{ uri: item.picture }} style={styles.productImage} />
              <View style={styles.productDetails}>
                <Text style={styles.productText}>{item.name}</Text>
                <Text style={styles.productPrice}>${item.price}</Text>
              </View>
              <View style={styles.actions}>
                <TouchableOpacity
                  style={styles.editButton}
                  onPress={() => {
                    setEditingProduct(item);
                    setName(item.name);
                    setPrice(item.price.toString());
                    setQuantity(item.quantity.toString());
                    setCategoryId(item.category_id.toString());
                    setImage(item.picture);
                    setModalVisible(true);
                  }}
                >
                  <Text style={styles.buttonText}>Edit</Text>
                </TouchableOpacity>
                <TouchableOpacity
                  style={styles.deleteButton}
                  onPress={() => handleDelete(item.product_id)}
                >
                  <Text style={styles.buttonText}>Delete</Text>
                </TouchableOpacity>
              </View>
            </View>
          )}
        />
      )}

      <Modal visible={modalVisible} transparent animationType="slide">
        <View style={styles.modalOverlay}>
          <View style={styles.modalContainer}>
            <Text style={styles.modalTitle}>
              {editingProduct ? "Edit Product" : "Add Product"}
            </Text>

            <TextInput
              placeholder="Product Name"
              value={name}
              onChangeText={setName}
              style={styles.input}
            />
            <TextInput
              placeholder="Price"
              keyboardType="numeric"
              value={price}
              onChangeText={setPrice}
              style={styles.input}
            />
            <TextInput
              placeholder="Quantity"
              keyboardType="numeric"
              value={quantity}
              onChangeText={setQuantity}
              style={styles.input}
            />
            <TextInput
              placeholder="Category ID"
              keyboardType="numeric"
              value={categoryId}
              onChangeText={setCategoryId}
              style={styles.input}
            />
            <TextInput
              placeholder="Image URL"
              value={image}
              onChangeText={setImage}
              style={styles.input}
            />

            <View style={styles.modalActions}>
              <TouchableOpacity
                style={[styles.modalButton, styles.saveButton]}
                onPress={handleSave}
              >
                <Text style={styles.buttonText}>Save</Text>
              </TouchableOpacity>
              <TouchableOpacity
                style={[styles.modalButton, styles.cancelButton]}
                onPress={() => {
                  setModalVisible(false);
                  resetForm();
                }}
              >
                <Text style={styles.buttonText}>Cancel</Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>
    </View>
  );
};

export default AdminProducts;

// نفس الستايلات تماماً كما طلبت
const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: "#F3F4F6" },
  header: {
    backgroundColor: "#009961",
    paddingVertical: 20,
    paddingHorizontal: 20,
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    borderBottomLeftRadius: 20,
    borderBottomRightRadius: 20,
    elevation: 4,
  },
  headerTitle: { fontSize: 20, fontWeight: "bold", color: "white" },
  searchContainer: { padding: 20 },
  input: {
    borderWidth: 1, borderColor: "#ccc", padding: 10,
    borderRadius: 8, backgroundColor: "white", marginBottom: 10,
  },
  productsContainer: { paddingVertical: 10 },
  productCard: {
    backgroundColor: "white", padding: 15, borderRadius: 12,
    marginBottom: 15, elevation: 3, flexDirection: "row",
    justifyContent: "space-between", alignItems: "center",
  },
  productImage: { width: 60, height: 60, borderRadius: 8, marginRight: 10 },
  productDetails: { flex: 1 },
  productText: { fontSize: 18, fontWeight: "bold", color: "#333" },
  productPrice: { fontSize: 16, fontWeight: "bold", color: "#009961" },
  actions: { flexDirection: "row" },
  editButton: {
    backgroundColor: "#1E90FF", padding: 8,
    borderRadius: 8, marginRight: 5,
  },
  deleteButton: { backgroundColor: "red", padding: 8, borderRadius: 8 },
  buttonText: { color: "white", fontWeight: "bold" },
  addButton: {
    backgroundColor: "#009961", padding: 12, borderRadius: 10,
    alignItems: "center", marginHorizontal: 20, marginVertical: 10,
  },
  addButtonText: { color: "white", fontSize: 16, fontWeight: "bold" },
  modalOverlay: {
    flex: 1, backgroundColor: "rgba(0,0,0,0.5)",
    justifyContent: "center", alignItems: "center",
  },
  modalContainer: {
    width: "90%", backgroundColor: "white", padding: 20,
    borderRadius: 15, elevation: 5,
  },
  modalTitle: {
    fontSize: 22, fontWeight: "bold", marginBottom: 15,
    textAlign: "center", color: "#333",
  },
  modalActions: {
    flexDirection: "row", justifyContent: "space-between",
    width: "100%", marginTop: 10,
  },
  modalButton: {
    flex: 1, padding: 12, borderRadius: 10,
    alignItems: "center", marginHorizontal: 5,
  },
  saveButton: { backgroundColor: "#009961" },
  cancelButton: { backgroundColor: "#ff4d4d" },
});
