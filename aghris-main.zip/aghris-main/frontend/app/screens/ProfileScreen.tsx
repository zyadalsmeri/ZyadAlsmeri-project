import React, { useEffect, useState } from 'react';
import { View, Text, Image, StyleSheet, TouchableOpacity, Alert } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useRouter } from 'expo-router';
import AsyncStorage from '@react-native-async-storage/async-storage';

export default function ProfileScreen() {
  const router = useRouter();
  const [user, setUser] = useState({ name: '', phone: '' });

  // ✅ جلب بيانات المستخدم عند فتح الصفحة
  useEffect(() => {
    const fetchUserData = async () => {
      try {
        const userData = await AsyncStorage.getItem('user');
        if (userData) {
          setUser(JSON.parse(userData)); // ✅ تحويل JSON إلى كائن
        }
      } catch (error) {
        console.error('❌ Error fetching user data:', error);
      }
    };

    fetchUserData();
  }, []);

  // ✅ وظيفة تسجيل الخروج
  const handleLogout = async () => {
    Alert.alert(
      "Log Out",
      "Are you sure you want to log out?",
      [
        { text: "Cancel", style: "cancel" },
        {
          text: "Log Out",
          onPress: async () => {
            await AsyncStorage.removeItem('token'); // ✅ حذف التوكن
            await AsyncStorage.removeItem('user'); // ✅ حذف بيانات المستخدم
            router.replace('/screens/HomeScreen'); // ✅ توجيه المستخدم إلى الصفحة الرئيسية
          },
        },
      ]
    );
  };

  return (
    <View style={styles.container}>
      {/* ✅ زر الرجوع إلى الصفحة الرئيسية */}
      <TouchableOpacity style={styles.header} onPress={() => router.replace('/screens/Login')}>
        <Ionicons name="arrow-back" size={24} color="black" />
        <Text style={styles.headerText}>Back</Text>
      </TouchableOpacity>

      {/* ✅ بيانات المستخدم */}
      <View style={styles.profileSection}>
        <Text style={styles.title}>My Profile</Text>
        <Image
          source={{ uri: 'https://placehold.co/100x100/green/white?text=User' }}
          style={styles.profileImage}
        />
        <Text style={styles.userName}>{user.name || "User Name"}</Text>
        <Text style={styles.userNumber}>{user.phone || "User Number"}</Text>
      </View>

      {/* ✅ الإعدادات */}
      <View style={styles.settingsSection}>
        <Text style={styles.settingsTitle}>Account Settings</Text>
        <TouchableOpacity 
  style={styles.settingItem} 
  onPress={() => router.push('/screens/ProfileEditScreen')} // 🔹 الانتقال لصفحة تعديل البروفايل
>
  <Image 
    source={{ uri: 'https://placehold.co/40x40/green/white?text=PS' }} 
    style={styles.settingIcon} 
  />
  <Text style={styles.settingText}>Profile setting</Text>
</TouchableOpacity>

        <TouchableOpacity style={styles.settingItem}>
          <Image source={{ uri: 'https://placehold.co/40x40/green/white?text=CP' }} style={styles.settingIcon} />
          <Text style={styles.settingText}>Change password</Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.settingItem}>
          <Image source={{ uri: 'https://placehold.co/40x40/green/white?text=CS' }} style={styles.settingIcon} />
          <Text style={styles.settingText}>Chat support</Text>
        </TouchableOpacity>

        {/* ✅ زر تسجيل الخروج */}
        <TouchableOpacity style={styles.settingItem} onPress={handleLogout}>
          <Image source={{ uri: 'https://placehold.co/40x40/green/white?text=LO' }} style={styles.settingIcon} />
          <Text style={[styles.settingText, { color: "red" }]}>Log out</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#DEEDFE',
    alignItems: 'center',
    justifyContent: 'center',
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    position: 'absolute',
    top: 50,
    left: 20,
  },
  headerText: {
    marginLeft: 10,
    color: '#A0AEC0',
  },
  profileSection: {
    alignItems: 'center',
    marginBottom: 20,
    padding: 20,
    borderRadius: 20,
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 20,
  },
  profileImage: {
    width: 100,
    height: 100,
    borderRadius: 50,
    marginBottom: 10,
  },
  userName: {
    fontSize: 20,
    fontWeight: 'bold',
  },
  userNumber: {
    color: '#A0AEC0',
  },
  settingsSection: {
    width: '80%',
    padding: 20,
    borderRadius: 20,
  },
  settingsTitle: {
    color: 'black',
    marginBottom: 20,
  },
  settingItem: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 20,
  },
  settingIcon: {
    width: 40,
    height: 40,
    marginRight: 20,
  },
  settingText: {
    fontSize: 16,
  },
});

