import React, { useEffect, useState } from "react";
import {
  View,
  Text,
  TouchableOpacity,
  StyleSheet,
  ScrollView,
  Alert,
  Animated,
  ActionSheetIOS,
  Platform,
} from "react-native";
import { Ionicons } from "@expo/vector-icons";
import { useRouter } from "expo-router";

const AdminUsersScreen = () => {
  const router = useRouter();
  const fadeAnim = useState(new Animated.Value(0))[0];

  const [users, setUsers] = useState([
    { id: 1, name: "John Doe", email: "john@example.com", phone: "0512345678", role: "User" },
    { id: 2, name: "Jane Smith", email: "jane@example.com", phone: "0598765432", role: "Supplier" },
    { id: 3, name: "Admin User", email: "admin@example.com", phone: "0556789123", role: "Admin" },
  ]);

  useEffect(() => {
    Animated.timing(fadeAnim, {
      toValue: 1,
      duration: 500,
      useNativeDriver: true,
    }).start();

    // 📌 **🔴 عند توفر API، قم بإزالة التعليق لتحميل بيانات المستخدمين**
    /*
    const fetchUsers = async () => {
      try {
        const response = await fetch("https://your-api.com/admin/users");
        const data = await response.json();
        setUsers(data);
      } catch (error) {
        console.error("Error fetching users:", error);
      }
    };
    fetchUsers();
    */
  }, []);

  // ✅ اختيار دور جديد للمستخدم عبر `ActionSheet`
  const changeUserRole = (id: number) => {
    const roles = ["User", "Supplier", "Admin"];

    if (Platform.OS === "ios") {
      ActionSheetIOS.showActionSheetWithOptions(
        {
          options: [...roles, "Cancel"],
          cancelButtonIndex: roles.length,
        },
        (selectedIndex) => {
          if (selectedIndex < roles.length) {
            updateUserRole(id, roles[selectedIndex]);
          }
        }
      );
    } else {
      Alert.alert("Change Role", "Select a new role for the user:", [
        ...roles.map((role) => ({
          text: role,
          onPress: () => updateUserRole(id, role),
        })),
        { text: "Cancel", style: "cancel" },
      ]);
    }
  };

  // ✅ تحديث دور المستخدم
  const updateUserRole = (id: number, newRole: string) => {
    setUsers((prevUsers) =>
      prevUsers.map((user) => (user.id === id ? { ...user, role: newRole } : user))
    );
    Alert.alert("✅ Success", `User #${id} role updated to ${newRole}`);

    // 📌 **🔴 عند توفر API، قم بإرسال التغيير إلى السيرفر**
    /*
    fetch(`https://your-api.com/admin/users/${id}`, {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ role: newRole }),
    });
    */
  };

  // ✅ حذف المستخدم بالكامل
  const deleteUser = (id: number) => {
    Alert.alert("⚠️ Confirm", `Are you sure you want to delete User #${id}?`, [
      { text: "Cancel", style: "cancel" },
      {
        text: "Delete",
        onPress: () => {
          setUsers((prevUsers) => prevUsers.filter((user) => user.id !== id));
          Alert.alert("🗑️ Deleted", `User #${id} has been removed.`);

          // 📌 **🔴 عند توفر API، قم بإرسال الطلب إلى السيرفر**
          /*
          fetch(`https://your-api.com/admin/users/${id}`, {
            method: "DELETE",
          });
          */
        },
      },
    ]);
  };

  return (
    <Animated.View style={[styles.container, { opacity: fadeAnim }]}>
      {/* ✅ الهيدر */}
      <View style={styles.header}>
        <TouchableOpacity onPress={() => router.back()} style={styles.backButton}>
          <Ionicons name="arrow-back" size={24} color="white" />
        </TouchableOpacity>
        <Text style={styles.headerTitle}>Users Management</Text>
        <Ionicons name="people-outline" size={24} color="white" />
      </View>

      {/* ✅ قائمة المستخدمين */}
      <ScrollView contentContainerStyle={styles.usersContainer}>
        {users.length === 0 ? (
          <Text style={styles.emptyText}>No users available.</Text>
        ) : (
          users.map((user) => (
            <View key={user.id} style={styles.userCard}>
              <View style={styles.userDetails}>
                <Text style={styles.userName}>{user.name}</Text>
                <Text style={styles.userEmail}>📧 {user.email}</Text>
                <Text style={styles.userPhone}>📞 {user.phone}</Text>
                <Text style={[styles.userRole, getRoleStyle(user.role)]}>
                  {user.role}
                </Text>
              </View>

              <View style={styles.actions}>
                {/* ✅ زر تغيير الدور */}
                <TouchableOpacity
                  style={[styles.actionButton, styles.roleButton]}
                  onPress={() => changeUserRole(user.id)}
                >
                  <Ionicons name="settings-outline" size={22} color="white" />
                </TouchableOpacity>

                {/* ✅ زر حذف المستخدم */}
                <TouchableOpacity
                  style={[styles.actionButton, styles.deleteButton]}
                  onPress={() => deleteUser(user.id)}
                >
                  <Ionicons name="trash-outline" size={22} color="white" />
                </TouchableOpacity>
              </View>
            </View>
          ))
        )}
      </ScrollView>
    </Animated.View>
  );
};

// ✅ **ألوان حسب دور المستخدم**
const getRoleStyle = (role: string) => {
  switch (role) {
    case "User":
      return { color: "#FFA500" };
    case "Supplier":
      return { color: "#1E90FF" };
    case "Admin":
      return { color: "#28A745" };
    default:
      return { color: "#333" };
  }
};
const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#F3F4F6",
  },
  header: {
    backgroundColor: "#009961",
    paddingVertical: 20,
    paddingHorizontal: 20,
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    borderBottomLeftRadius: 20,
    borderBottomRightRadius: 20,
    elevation: 4,
  },
  headerTitle: {
    fontSize: 20,
    fontWeight: "bold",
    color: "white",
  },
  backButton: {
    padding: 5,
  },
  usersContainer: {
    padding: 20,
    alignItems: "center",
  },
  emptyText: {
    fontSize: 18,
    color: "#666",
    textAlign: "center",
    marginTop: 50,
  },

  userCard: {
    backgroundColor: "white",
    width: "90%",
    padding: 15,
    borderRadius: 12,
    marginBottom: 15,
    elevation: 3,
    flexDirection: "row", // 🔹 استخدام `row` لتحديد مساحات العناصر
    justifyContent: "space-between",
    alignItems: "center",
    shadowColor: "#000",
    shadowOpacity: 0.1,
    shadowRadius: 5,
    shadowOffset: { width: 0, height: 2 },
  },

  userDetails: {
    flex: 1, // 🔹 تحديد حجم العنصر
  },

  userName: {
    fontSize: 18,
    fontWeight: "bold",
    color: "#333",
    marginBottom: 5, // 🔹 مسافة بين الاسم والبريد
  },
  userEmail: {
    fontSize: 16,
    color: "#666",
    marginBottom: 5, // 🔹 مسافة بين البريد والهاتف
  },
  userPhone: {
    fontSize: 16,
    fontWeight: "bold",
    color: "#009961",
    marginBottom: 5, // 🔹 مسافة بين الهاتف والدور
  },
  userRole: {
    fontSize: 14,
    fontWeight: "bold",
    color: "#333",
  },

  actions: {
    flexDirection: "row",
    alignItems: "center",
  },
  actionButton: {
    padding: 10,
    borderRadius: 8,
    marginLeft: 10,
    justifyContent: "center",
    alignItems: "center",
  },
  roleButton: {
    backgroundColor: "#1E90FF",
  },
  deleteButton: {
    backgroundColor: "red",
  },
});


export default AdminUsersScreen;
