import React, { useRef, useEffect, useState } from 'react';
import {
  View, Text, TouchableOpacity, StyleSheet, ScrollView, Animated, Alert
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useRouter } from 'expo-router';
import AsyncStorage from '@react-native-async-storage/async-storage';
import AuthGuard from '@/components/AuthGuard';
import { BASE_URL } from '@/constants/config';

const AdminDashboard = () => {
  const router = useRouter();
  const scaleAnim = useRef(new Animated.Value(1)).current;

  const [stats, setStats] = useState({ orders: 0, products: 0, users: 0 });

  useEffect(() => {
    const fetchStats = async () => {
      try {
        const token = await AsyncStorage.getItem("token");
        const response = await fetch(`${BASE_URL}/api/admin/stats`, {
          method: 'GET',
          headers: {
            'Content-Type': 'application/json',
            Authorization: `Bearer ${token}`,
          },
        });

        const data = await response.json();
        setStats({
          orders: data.orders || 0,
          products: data.products || 0,
          users: data.users || 0,
        });
      } catch (error) {
        console.error("Failed to load stats:", error);
      }
    };

    fetchStats();
  }, []);

  const handlePress = (screen: string) => {
    Animated.sequence([
      Animated.timing(scaleAnim, {
        toValue: 0.95,
        duration: 100,
        useNativeDriver: true,
      }),
      Animated.timing(scaleAnim, {
        toValue: 1,
        duration: 100,
        useNativeDriver: true,
      }),
    ]).start(() => {
      router.push(screen as any);
    });
  };

  return (
    <AuthGuard allowedRoles={['Admin']}>
      <ScrollView contentContainerStyle={styles.container}>
        <TouchableOpacity style={styles.logoutButton} onPress={() => Alert.alert('Logged out')}>
          <Ionicons name="log-out-outline" size={24} color="#333" />
        </TouchableOpacity>

        <Text style={styles.headerTitle}>Admin Dashboard</Text>

        <View style={styles.cardsContainer}>
          {[
            { title: 'Total Orders', value: stats.orders.toString(), icon: 'cart-outline', screen: '/screens/AdminOrders' },
            { title: 'Total Products', value: stats.products.toString(), icon: 'leaf-outline', screen: '/screens/AdminProducts' },
            { title: 'Total Users', value: stats.users.toString(), icon: 'people-outline', screen: '/screens/AdminUsersScreen' }
          ].map((item, index) => (
            <TouchableOpacity key={index} style={[styles.card, styles.shadow]} onPress={() => handlePress(item.screen)}>
              <Ionicons name={item.icon as any} size={40} color="white" />
              <Text style={styles.cardTitle}>{item.title}</Text>
              <Text style={styles.cardValue}>{item.value}</Text>
            </TouchableOpacity>
          ))}
        </View>

        <View style={styles.optionsContainer}>
          {[
            { title: 'Manage Orders', icon: 'list-outline', screen: '/screens/AdminOrdersScreen' },
            { title: 'Manage Products', icon: 'pricetag-outline', screen: '/screens/AdminProducts' },
            { title: 'Manage Users', icon: 'person-outline', screen: '/screens/AdminUsersScreen' }
          ].map((item, index) => (
            <TouchableOpacity key={index} style={[styles.option, styles.shadow]} onPress={() => handlePress(item.screen)}>
              <Ionicons name={item.icon as any} size={24} color="#fff" />
              <Text style={styles.optionText}>{item.title}</Text>
            </TouchableOpacity>
          ))}
        </View>
      </ScrollView>
    </AuthGuard>
  );
};

const styles = StyleSheet.create({
  // ... نفس الستايل حقك ما تغيّر 👌
  container: {
    flexGrow: 1,
    backgroundColor: '#ECF8F3',
    paddingVertical: 30,
    alignItems: 'center',
  },
  logoutButton: {
    position: 'absolute',
    top: 50,
    right: 20,
  },
  headerTitle: {
    fontSize: 26,
    fontWeight: 'bold',
    color: '#333',
    marginBottom: 25,
    padding: 30,
  },
  cardsContainer: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'center',
    width: '90%',
  },
  card: {
    backgroundColor: '#009961',
    width: '42%',
    padding: 25,
    borderRadius: 15,
    alignItems: 'center',
    margin: 10,
    elevation: 5,
  },
  shadow: {
    shadowColor: '#000',
    shadowOpacity: 0.2,
    shadowRadius: 10,
    shadowOffset: { width: 0, height: 4 },
  },
  cardTitle: {
    color: 'white',
    fontSize: 14,
    marginTop: 8,
  },
  cardValue: {
    color: 'white',
    fontSize: 20,
    fontWeight: 'bold',
    marginTop: 4,
  },
  optionsContainer: {
    width: '90%',
    marginTop: 50,
  },
  option: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#009961',
    paddingVertical: 14,
    paddingHorizontal: 15,
    borderRadius: 12,
    marginBottom: 15,
  },
  optionText: {
    color: 'white',
    fontSize: 18,
    marginLeft: 12,
  },
});

export default AdminDashboard;
