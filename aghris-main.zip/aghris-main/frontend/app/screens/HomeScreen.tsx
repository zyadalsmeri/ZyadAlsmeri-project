import React, { useState } from 'react';
import {
  StyleSheet, View, Text, TextInput, TouchableOpacity, ScrollView,
  KeyboardAvoidingView, Platform, Alert, ActivityIndicator
} from 'react-native';
import { useRouter } from 'expo-router';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { BASE_URL } from '@/constants/config';
import { useCart } from '@/app/context/CartContext'; // ✅ استيراد useCart

const LoginScreen = () => {
  const router = useRouter();
  const { fetchCart } = useCart(); // ✅ استخدام الكونتكست
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);

  const handleLogin = async () => {
    if (!email || !password) {
      Alert.alert('❌ Error', 'Please enter both email and password.');
      return;
    }

    setLoading(true);
    try {
      const response = await fetch(`${BASE_URL}/auth/login`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ Email: email, Password: password }),
      });

      if (!response.ok) {
        throw new Error('❌ Invalid email or password');
      }

      const data = await response.json();

      if (!data.token) {
        throw new Error("Login successful, but token is missing.");
      }

      await AsyncStorage.setItem('token', data.token);
      await AsyncStorage.setItem('role', data.role.toLowerCase());

      await fetchCart(); // ✅ تحديث بيانات السلة مباشرة

      Alert.alert('✅ Success', 'Logged in successfully!');
      router.replace(data.role.toLowerCase() === 'admin' ? '/screens/AdminDashboard' : '/screens/HomeScreen');

    } catch (error: unknown) {
      let errorMessage = 'An unknown error occurred';
      if (error instanceof Error) {
        errorMessage = error.message;
      }
      Alert.alert('❌ Login Error', errorMessage);
    } finally {
      setLoading(false);
    }
  };

  return (
    <KeyboardAvoidingView behavior={Platform.OS === 'ios' ? 'padding' : 'height'} style={styles.container}>
      <ScrollView contentContainerStyle={styles.scrollContainer} keyboardShouldPersistTaps="handled">
        <View style={styles.headerContainer}>
          <Text style={styles.title}>Welcome to</Text>
          <Text style={styles.titleHighlight}>Aghris</Text>
        </View>

        <View style={styles.formContainer}>
          <Text style={styles.loginText}>Login</Text>
          <Text style={styles.instructions}>Enter your email and password to login</Text>

          <TextInput
            style={styles.input}
            placeholder="Email"
            autoCapitalize="none"
            keyboardType="email-address"
            placeholderTextColor="#757575"
            value={email}
            onChangeText={setEmail}
          />
          <TextInput
            style={styles.input}
            placeholder="Password"
            secureTextEntry
            placeholderTextColor="#757575"
            value={password}
            onChangeText={setPassword}
          />

          <TouchableOpacity style={styles.button} onPress={handleLogin} disabled={loading}>
            {loading ? <ActivityIndicator color="#fff" /> : <Text style={styles.buttonText}>Login</Text>}
          </TouchableOpacity>

          <Text style={styles.footerText}>
            If you do not have an account{' '}
            <Text style={styles.link} onPress={() => router.push('/screens/Register')}>click here</Text>.
          </Text>
        </View>
      </ScrollView>
    </KeyboardAvoidingView>
  );
};

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#f7fafc' },
  scrollContainer: { flexGrow: 1, alignItems: 'center', padding: 30 },
  headerContainer: { alignItems: 'center', marginBottom: 40, marginTop: 50 },
  title: { fontSize: 28, fontWeight: 'bold', textAlign: 'center', color: 'black' },
  titleHighlight: { fontSize: 28, fontWeight: 'bold', textAlign: 'center', color: '#388E3C' },
  formContainer: { width: '100%', alignItems: 'center' },
  loginText: { fontSize: 22, fontWeight: 'bold', marginVertical: 20, color: 'black' },
  input: { width: '100%', padding: 15, marginVertical: 10, borderBottomWidth: 1, borderBottomColor: '#B0BEC5', backgroundColor: 'white', borderRadius: 5, color: 'black' },
  button: { backgroundColor: '#000000', padding: 15, alignItems: 'center', marginVertical: 20, borderRadius: 5, width: '100%' },
  buttonText: { color: '#FFFFFF', fontWeight: 'bold' },
  instructions: {
    fontSize: 16,
    color: '#666',
    padding: 10,
    textAlign: 'center',
  },
  footerText: {
    textAlign: 'center',
    color: 'black',
  },
  link: {
    color: '#1E88E5',
    fontWeight: 'bold',
  },
});

export default LoginScreen;
