import React, { useState, useEffect } from 'react';
import { View, Text, TextInput, TouchableOpacity, StyleSheet, Alert, KeyboardAvoidingView, Platform } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { useRouter } from 'expo-router';

const ProfileEditScreen = () => {
  const router = useRouter();

  const [fullName, setFullName] = useState('');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [address, setAddress] = useState('');

  useEffect(() => {
    const loadProfile = async () => {
      const storedName = await AsyncStorage.getItem('fullName');
      const storedEmail = await AsyncStorage.getItem('email');
      const storedPhone = await AsyncStorage.getItem('phone');
      const storedAddress = await AsyncStorage.getItem('address');

      if (storedName) setFullName(storedName);
      if (storedEmail) setEmail(storedEmail);
      if (storedPhone) setPhone(storedPhone);
      if (storedAddress) setAddress(storedAddress);
    };

    loadProfile();
  }, []);

  // ✅ التحقق من صحة رقم الجوال (يجب أن يبدأ بـ "05" ويحتوي على 10 أرقام)
  const validatePhone = (number: string) => /^05\d{8}$/.test(number);

  const handleSave = async () => {
    if (!fullName || !email || !phone || !address) {
      Alert.alert('❌ Error', 'Please fill in all fields before saving.');
      return;
    }

    if (!validatePhone(phone)) {
      Alert.alert('❌ Error', 'Phone number must be 10 digits and start with 05.');
      return;
    }

    try {
      await AsyncStorage.setItem('fullName', fullName);
      await AsyncStorage.setItem('email', email);
      await AsyncStorage.setItem('phone', phone);
      await AsyncStorage.setItem('address', address);

      Alert.alert('✅ Success', 'Profile updated successfully!');
      router.push('/screens/ProfileScreen'); // 🔹 الرجوع إلى صفحة الملف الشخصي
    } catch (error) {
      Alert.alert('❌ Error', 'Failed to update profile.');
    }
  };

  return (
    <KeyboardAvoidingView behavior={Platform.OS === 'ios' ? 'padding' : 'height'} style={styles.container}>
      {/* 🔹 زر الرجوع في الأعلى يسار */}
      <TouchableOpacity style={styles.backButton} onPress={() => router.push('/screens/ProfileScreen')}>
        <Ionicons name="arrow-back" size={24} color="black" />
      </TouchableOpacity>

      {/* 🔹 العنوان في المنتصف العلوي */}
      <Text style={styles.title}>Edit Profile</Text>

      {/* 🔹 جعل الحقول في المنتصف تمامًا */}
      <View style={styles.formContainer}>
        <TextInput
          style={styles.input}
          placeholder="Full Name"
          value={fullName}
          onChangeText={setFullName}
        />
        <TextInput
          style={styles.input}
          placeholder="Email"
          value={email}
          keyboardType="email-address"
          onChangeText={setEmail}
        />
        <TextInput
          style={styles.input}
          placeholder="Phone (05xxxxxxxx)"
          value={phone}
          keyboardType="phone-pad"
          onChangeText={setPhone}
          maxLength={10}
        />
        <TextInput
          style={styles.input}
          placeholder="Address"
          value={address}
          onChangeText={setAddress}
        />
      </View>

      {/* 🔹 زر الحفظ في الأسفل */}
      <TouchableOpacity style={styles.saveButton} onPress={handleSave}>
        <Text style={styles.saveButtonText}>Save Changes</Text>
      </TouchableOpacity>
    </KeyboardAvoidingView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#DEEDFE',
    justifyContent: 'space-between', // 🔹 جعل زر الحفظ في الأسفل والإنبوتات في المنتصف
    paddingVertical: 30,
  },
  backButton: {
    position: 'absolute',
    top: 50,
    left: 20,
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    textAlign: 'center',
    position: 'absolute',
    top: 100,
    left: 0,
    right: 0,
  },
  formContainer: {
    flex: 1,
    justifyContent: 'center', // 🔹 تمركز الحقول في المنتصف
    paddingHorizontal: 20,
  },
  input: {
    width: '100%',
    backgroundColor: '#fff',
    padding: 15,
    borderRadius: 10,
    marginBottom: 15,
    fontSize: 16,
    textAlign: 'center',
  },
  saveButton: {
    backgroundColor: '#009961',
    padding: 15,
    borderRadius: 10,
    width: '90%',
    alignSelf: 'center',
    marginBottom: 30, // 🔹 وضع الزر في الأسفل
  },
  saveButtonText: {
    color: 'white',
    fontSize: 16,
    fontWeight: 'bold',
    textAlign: 'center',
  },
});

export default ProfileEditScreen;
