import React, { useState, useEffect } from 'react';
import { View, Text, Image, TouchableOpacity, StyleSheet, Dimensions, ActivityIndicator, Alert } from 'react-native';
import { FontAwesome } from '@expo/vector-icons';
import { useRouter, useLocalSearchParams } from 'expo-router';
import { useCart } from '../context/CartContext';
import { BASE_URL } from '@/constants/config'; // ✅ استيراد API URL

const { width, height } = Dimensions.get('window');

const ProductScreen = () => {
  const router = useRouter();
  const { id } = useLocalSearchParams(); // ✅ جلب ID المنتج من التنقل
  const { addToCart } = useCart();
  const [quantity, setQuantity] = useState(1);
  type Product = {
    id: number;
    name: string;
    image_url: string;
    description: string;
    price: number;
  };
  
  const [product, setProduct] = useState<Product | null>(null);
    const [loading, setLoading] = useState(true); // ✅ عرض اللودينج أثناء تحميل البيانات

  // ✅ جلب بيانات المنتج من API عند تحميل الصفحة
  useEffect(() => {
    const fetchProduct = async () => {
      try {
        const response = await fetch(`${BASE_URL}/products/${id}`); // 🔹 جلب المنتج بناءً على الـ ID
        const data = await response.json();
        
        if (!response.ok) {
          throw new Error(data.message || 'Failed to fetch product');
        }

        setProduct(data); // ✅ تحديث الحالة بالمنتج المسترجع
      } catch (error) {
        console.error("❌ Error fetching product:", error);
        Alert.alert("❌ Error", "Failed to load product details.");
      } finally {
        setLoading(false); // ✅ إيقاف اللودينج بعد انتهاء الجلب
      }
    };

    if (id) {
      fetchProduct();
    }
  }, [id]);

  // ✅ إظهار اللودينج أثناء تحميل المنتج
  if (loading) {
    return (
      <View style={styles.loadingContainer}>
        <ActivityIndicator size="large" color="#009961" />
      </View>
    );
  }

  // ✅ إذا لم يتم العثور على المنتج
  if (!product) {
    return (
      <View style={styles.loadingContainer}>
        <Text style={styles.errorText}>❌ Product not found.</Text>
      </View>
    );
  }

  const handleAddToCart = () => {
    const cartItem = {
      id: product.id,
      title: product.name, // ✅ تحويل `name` إلى `title`
      image: product.image_url, // ✅ تحويل `image_url` إلى `image`
      description: product.description,
      price: product.price,
      quantity
    };
  
    addToCart(cartItem); // ✅ إرسال المنتج بصيغة صحيحة
    alert('✅ Product added to cart!');
  };
  

  return (
    <View style={styles.container}>
      {/* ✅ شريط العنوان */}
      <View style={styles.header}>
        <TouchableOpacity onPress={() => router.back()}>
          <FontAwesome name="arrow-left" size={20} color="black" />
        </TouchableOpacity>
        <Text style={styles.title}>
          {product.name.split(' ')[0]} <Text style={styles.boldText}>{product.name.split(' ')[1]}</Text>
        </Text>
        <TouchableOpacity onPress={() => router.push('/screens/ProfileScreen')}>
          <FontAwesome name="bars" size={20} color="black" />
        </TouchableOpacity>
      </View>

      {/* ✅ صورة المنتج */}
      <View style={styles.imageContainer}>
        <Image source={{ uri: product.image_url }} style={styles.productImage} resizeMode="contain" />
        <Text style={styles.backgroundText}>Plants</Text>
      </View>

      {/* ✅ وصف المنتج */}
      <Text style={styles.description}>{product.description}</Text>

      {/* ✅ التحكم في الكمية */}
      <View style={styles.bottomSection}>
        <View style={styles.quantityContainer}>
          <TouchableOpacity onPress={() => setQuantity(Math.max(1, quantity - 1))} style={styles.quantityButton}>
            <Text style={styles.quantityText}>-</Text>
          </TouchableOpacity>
          <Text style={styles.quantityNumber}>{quantity < 10 ? `0${quantity}` : quantity}</Text>
          <TouchableOpacity onPress={() => setQuantity(quantity + 1)} style={styles.quantityButton}>
            <Text style={styles.quantityText}>+</Text>
          </TouchableOpacity>
        </View>

        {/* ✅ زر الإضافة إلى السلة */}
        <TouchableOpacity style={styles.addToCartButton} onPress={handleAddToCart}>
          <FontAwesome name="shopping-cart" size={18} color="white" />
          <Text style={styles.addToCartText}> Add to Cart</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
};

export default ProductScreen;

const styles = StyleSheet.create({
  loadingContainer: { flex: 1, justifyContent: 'center', alignItems: 'center' }, // ✅ إضافة `loadingContainer`
  errorText: { fontSize: 18, fontWeight: 'bold', color: 'red' }, // ✅ إضافة `errorText`
  container: {
    flex: 1,
    backgroundColor: '#F9F9F9',
    padding: 20,
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    width: '100%',
    alignItems: 'center',
    marginTop: 40,
  },
  title: {
    fontSize: 22,
    color: '#333',
  },
  boldText: {
    fontWeight: 'bold',
  },
  imageContainer: {
    marginTop: 20,
    alignItems: 'center',
  },
  productImage: {
    width: 220,
    height: 250,
  },
  backgroundText: {
    position: 'absolute',
    top: 90,
    fontSize: 60,
    fontWeight: 'bold',
    color: 'rgba(0, 200, 0, 0.1)',
  },
  description: {
    textAlign: 'center',
    color: '#666',
    marginTop: 20,
    fontSize: 14,
    paddingHorizontal: 20,
  },
  bottomSection: {
    width: '100%',
    position: 'absolute',
    bottom: 20,
    alignItems: 'center',
  },
  quantityContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    width: '80%',
    alignItems: 'center',
    marginBottom: 20,
  },
  quantityButton: {
    backgroundColor: '#E6E6E6',
    width: 50,
    height: 50,
    borderRadius: 25,
    alignItems: 'center',
    justifyContent: 'center',
  },
  quantityText: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#333',
  },
  quantityNumber: {
    fontSize: 28,
    fontWeight: 'bold',
  },
  addToCartButton: {
    flexDirection: 'row',
    backgroundColor: 'black',
    width: '90%',
    paddingVertical: 15,
    borderRadius: 30,
    alignItems: 'center',
    justifyContent: 'center',
  },
  addToCartText: {
    color: 'white',
    fontSize: 16,
    fontWeight: 'bold',
    marginLeft: 10,
  },
});
