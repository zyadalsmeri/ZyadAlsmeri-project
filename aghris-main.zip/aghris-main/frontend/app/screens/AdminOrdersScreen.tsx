import React, { useEffect, useState } from 'react';
import { View, Text, TouchableOpacity, StyleSheet, ScrollView, Alert, Animated } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useRouter } from 'expo-router';

const AdminOrdersScreen = () => {
  const router = useRouter();
  const fadeAnim = useState(new Animated.Value(0))[0];

  const [orders, setOrders] = useState([
    { id: 1, customer: 'John Doe', total: '150 SR', status: 'Pending' },
    { id: 2, customer: 'Jane Smith', total: '200 SR', status: 'Shipped' },
    { id: 3, customer: 'Alice Johnson', total: '300 SR', status: 'Delivered' },
  ]);

  useEffect(() => {
    Animated.timing(fadeAnim, {
      toValue: 1,
      duration: 500,
      useNativeDriver: true,
    }).start();
  }, []);

  // ✅ تحديث حالة الطلب
  const updateOrderStatus = (id: number, newStatus: string) => {
    Animated.timing(fadeAnim, {
      toValue: 0.5,
      duration: 300,
      useNativeDriver: true,
    }).start(() => {
      setOrders((prevOrders) =>
        prevOrders.map((order) =>
          order.id === id ? { ...order, status: newStatus } : order
        )
      );
      Alert.alert('✅ Success', `Order #${id} updated to ${newStatus}`);
      Animated.timing(fadeAnim, {
        toValue: 1,
        duration: 300,
        useNativeDriver: true,
      }).start();
    });
  };

  // ✅ حذف الطلب مع تأثير الحركة
  const deleteOrder = (id: number) => {
    Animated.timing(fadeAnim, {
      toValue: 0,
      duration: 300,
      useNativeDriver: true,
    }).start(() => {
      setOrders((prevOrders) => prevOrders.filter((order) => order.id !== id));
      Alert.alert('🗑️ Deleted', `Order #${id} has been removed`);
      Animated.timing(fadeAnim, {
        toValue: 1,
        duration: 300,
        useNativeDriver: true,
      }).start();
    });
  };

  return (
    <Animated.View style={[styles.container, { opacity: fadeAnim }]}>
      <View style={styles.header}>
        <TouchableOpacity onPress={() => router.back()} style={styles.backButton}>
          <Ionicons name="arrow-back" size={24} color="white" />
        </TouchableOpacity>
        <Text style={styles.headerTitle}>Orders Management</Text>
        <Ionicons name="list-outline" size={24} color="white" />
      </View>

      <ScrollView contentContainerStyle={styles.ordersContainer}>
        {orders.length === 0 ? (
          <Text style={styles.emptyText}>No orders available.</Text>
        ) : (
          orders.map((order) => (
            <TouchableOpacity 
              key={order.id} 
              style={styles.orderCard}
              onPress={() => router.push(`/screens/AdminOrderDetailsScreen?orderId=${order.id}`)}
            >
              <View style={styles.orderDetails}>
                <Text style={styles.customerName}>{order.customer}</Text>
                <Text style={styles.orderTotal}>💰 {order.total}</Text>
                <Text style={[styles.orderStatus, getStatusStyle(order.status)]}>
                  {order.status}
                </Text>
              </View>

              <View style={styles.actions}>
                {order.status === 'Pending' && (
                  <TouchableOpacity
                    style={[styles.actionButton, styles.shipButton]}
                    onPress={() => updateOrderStatus(order.id, 'Shipped')}
                  >
                    <Ionicons name="send-outline" size={22} color="white" />
                  </TouchableOpacity>
                )}

                {order.status !== 'Delivered' && (
                  <TouchableOpacity
                    style={[styles.actionButton, styles.deliverButton]}
                    onPress={() => updateOrderStatus(order.id, 'Delivered')}
                  >
                    <Ionicons name="checkmark-circle-outline" size={22} color="white" />
                  </TouchableOpacity>
                )}

                <TouchableOpacity
                  style={[styles.actionButton, styles.deleteButton]}
                  onPress={() => deleteOrder(order.id)}
                >
                  <Ionicons name="trash-outline" size={22} color="white" />
                </TouchableOpacity>
              </View>
            </TouchableOpacity>
          ))
        )}
      </ScrollView>
    </Animated.View>
  );
};

// ✅ **حالة الألوان حسب حالة الطلب**
const getStatusStyle = (status: string) => {
  switch (status) {
    case 'Pending':
      return { color: '#FFA500' };
    case 'Shipped':
      return { color: '#1E90FF' };
    case 'Delivered':
      return { color: '#28A745' };
    default:
      return { color: '#333' };
  }
};

// ✅ **التنسيق الاحترافي**
const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F3F4F6',
  },
  header: {
    backgroundColor: '#009961',
    paddingVertical: 20,
    paddingHorizontal: 20,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    borderBottomLeftRadius: 20,
    borderBottomRightRadius: 20,
    elevation: 4,
  },
  headerTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: 'white',
  },
  backButton: {
    padding: 5,
  },
  ordersContainer: {
    padding: 20,
    alignItems: 'center',
  },
  emptyText: {
    fontSize: 18,
    color: '#666',
    textAlign: 'center',
    marginTop: 50,
  },
  orderCard: {
    backgroundColor: 'white',
    width: '90%',
    padding: 15,
    borderRadius: 12,
    marginBottom: 15,
    elevation: 3,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    shadowColor: '#000',
    shadowOpacity: 0.1,
    shadowRadius: 5,
    shadowOffset: { width: 0, height: 2 },
  },
  orderDetails: {
    flex: 1,
  },
  customerName: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#333',
  },
  orderTotal: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#009961',
    marginVertical: 3,
  },
  orderStatus: {
    fontSize: 14,
    fontWeight: 'bold',
  },
  actions: {
    flexDirection: 'row',
  },
  actionButton: {
    padding: 10,
    borderRadius: 8,
    marginLeft: 10,
    justifyContent: 'center',
    alignItems: 'center',
  },
  shipButton: {
    backgroundColor: '#1E90FF',
  },
  deliverButton: {
    backgroundColor: '#28A745',
  },
  deleteButton: {
    backgroundColor: 'red',
  },
});

export default AdminOrdersScreen;
