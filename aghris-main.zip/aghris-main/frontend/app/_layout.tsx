import { DarkTheme, DefaultTheme, ThemeProvider } from '@react-navigation/native';
import { useFonts } from 'expo-font';
import { Stack } from 'expo-router';
import * as SplashScreen from 'expo-splash-screen';
import { StatusBar } from 'expo-status-bar';
import { useEffect, useState } from 'react';
import 'react-native-reanimated';

import { useColorScheme } from '@/hooks/useColorScheme';
import CartProvider from './context/CartContext'; // ✅ تأكد من أن المسار صحيح
import AsyncStorage from '@react-native-async-storage/async-storage';

SplashScreen.preventAutoHideAsync(); // ✅ منع الشاشة الافتتاحية حتى يتم تحميل البيانات

export default function RootLayout() {
  const colorScheme = useColorScheme();
  const [loaded] = useFonts({
    SpaceMono: require('@/assets/fonts/SpaceMono-Regular.ttf'),
  });

  const [isAuthenticated, setIsAuthenticated] = useState<boolean | null>(null);

  useEffect(() => {
    const checkAuth = async () => {
      try {
        const token = await AsyncStorage.getItem('token');
        setIsAuthenticated(!!token); // ✅ التحقق من وجود `token`
      } catch (error) {
        console.error("❌ Error checking auth:", error);
      } finally {
        SplashScreen.hideAsync(); // ✅ إخفاء `SplashScreen` بعد تحميل البيانات
      }
    };

    if (loaded) {
      checkAuth();
    }
  }, [loaded]);

  if (!loaded || isAuthenticated === null) {
    return null; // ✅ إظهار شاشة فارغة حتى يتم التحقق من تسجيل الدخول
  }

  return (
    <CartProvider> {/* ✅ لف التطبيق بـ CartProvider لجعل `useCart()` متاحًا */}  
      <ThemeProvider value={colorScheme === 'dark' ? DarkTheme : DefaultTheme}>
        <Stack screenOptions={{ headerShown: false }}>
          {/* ✅ توجيه المستخدم حسب حالة تسجيل الدخول */}
          {isAuthenticated ? (
            <>
              <Stack.Screen name="(tabs)" options={{ headerShown: false }} />
              <Stack.Screen name="screens/HomeScreen" options={{ headerShown: false }} />
              <Stack.Screen name="screens/CartScreen" options={{ headerShown: false }} />
              <Stack.Screen name="screens/TrackOrderScreen" options={{ headerShown: false }} />
              <Stack.Screen name="screens/ProductDetails" options={{ headerShown: false }} />
              <Stack.Screen name="screens/Profile" options={{ headerShown: false }} />
            </>
          ) : (
            <>
              <Stack.Screen name="screens/Login" options={{ headerShown: false }} />
              <Stack.Screen name="screens/Register" options={{ headerShown: false }} />
            </>
          )}
          <Stack.Screen name="screens/NotFoundScreen" options={{ title: "Page Not Found" }} />
        </Stack>
        <StatusBar style="auto" />
      </ThemeProvider>
    </CartProvider>
  );
}
