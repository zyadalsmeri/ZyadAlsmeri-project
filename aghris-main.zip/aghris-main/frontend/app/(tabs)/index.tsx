import HomeScreen from '../screens/HomeScreen'; // ✅ استخدم المسار الصحيح

export default function Index() {
  return <HomeScreen />;
}
