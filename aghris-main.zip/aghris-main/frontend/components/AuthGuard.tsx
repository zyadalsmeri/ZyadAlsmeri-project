import React, { useEffect, useState } from 'react';
import { View, ActivityIndicator, Alert } from 'react-native';
import { useRouter } from 'expo-router';
import AsyncStorage from '@react-native-async-storage/async-storage';

const AuthGuard = ({ children, allowedRoles }: { children: React.ReactNode, allowedRoles: string[] }) => {
  const router = useRouter();
  const [role, setRole] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const checkAuth = async () => {
      const storedRole = await AsyncStorage.getItem('role');
      if (!storedRole || !allowedRoles.includes(storedRole)) {
        Alert.alert('❌ Access Denied', 'You do not have permission to access this page.');
        router.replace('/screens/Login');
      } else {
        setRole(storedRole);
      }
      setLoading(false);
    };
    
    checkAuth();
  }, []);

  if (loading) {
    return <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}><ActivityIndicator size="large" /></View>;
  }

  return <>{children}</>;
};

export default AuthGuard;
