// components/CurvedButton.tsx
import React from 'react';
import { Text, TouchableOpacity, StyleSheet, ViewStyle } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';

type Props = {
  onPress: () => void;
  icon?: string;
  style?: ViewStyle;
  reversed?: boolean;
};

const CurvedButton = ({ onPress, icon = '+', style, reversed = false }: Props) => {
  return (
    <TouchableOpacity onPress={onPress} style={[styles.wrapper, style]}>
      <LinearGradient
        colors={['#DCEBFE', 'rgba(220,235,254,0)']}
        start={{ x: reversed ? 1 : 0, y: 0 }}
        end={{ x: reversed ? 0 : 1, y: 0 }}
        style={[
          styles.gradient,
          reversed
            ? {
                borderTopRightRadius: 60,
                borderBottomRightRadius: 60,
                borderTopLeftRadius: 0,
                borderBottomLeftRadius: 0,
              }
            : {},
        ]}
      >
        <Text style={styles.icon}>{icon}</Text>
      </LinearGradient>
    </TouchableOpacity>
  );
};

export default CurvedButton;

const styles = StyleSheet.create({
  wrapper: {
    width: 44,
    height: 103,
  },
  gradient: {
    flex: 1,
    borderTopLeftRadius: 60,
    borderBottomLeftRadius: 60,
    justifyContent: 'center',
    alignItems: 'center',
  },
  icon: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#000',
  },
});
